$(document).ready(function() {
	$('#dlModal').show();
});

/*$(function() {
	$('#modal-close').click(function() {
		$('#dlModal').hide();
	});
});*/