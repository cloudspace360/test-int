package com.se.wp.library.soap.bsl.config;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;
import org.springframework.ws.transport.http.HttpComponentsMessageSender;

import com.se.wp.library.utils.EnvironmentUtil;

import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(MockitoExtension.class)	
public class SoapBslConfigTest  {

	@InjectMocks
	SoapBslConfig soapBslConfig;

	@Test
	public void testDocumentServiceMarshallerTest() {
		String contextPath="com.schneider.oreo.service.document";
		assertEquals(contextPath,soapBslConfig.documentServiceMarshaller().getContextPath());

	}
	@Test
	public void testDocumentServiceClientTest()
	{
		Jaxb2Marshaller documentServiceMarshaller = new Jaxb2Marshaller();
		HttpComponentsMessageSender documentServicesMessageSender= new HttpComponentsMessageSender();
		assertEquals(documentServiceMarshaller, soapBslConfig.documentServiceClient(documentServiceMarshaller,documentServicesMessageSender).getMarshaller());
		assertEquals(documentServiceMarshaller, soapBslConfig.documentServiceClient(documentServiceMarshaller,documentServicesMessageSender).getUnmarshaller());
	}

	@Test
	public void testDocumentServicesMessageSenderTest() {
		soapBslConfig.documentServicesMessageSender();
	}

}
