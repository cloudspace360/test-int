package com.se.wp.library.soap.bsl.clinet;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.JAXBElement;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;
import org.springframework.ws.client.core.WebServiceTemplate;
import org.springframework.ws.transport.http.HttpComponentsMessageSender;

import com.schneider.oreo.service.document.AttType;
import com.schneider.oreo.service.document.DocCountByBean;
import com.schneider.oreo.service.document.DocDisplayBean;
import com.schneider.oreo.service.document.DocDisplayBeans;
import com.schneider.oreo.service.document.DocDisplayFieldBean;
import com.schneider.oreo.service.document.DocOrderBean;
import com.schneider.oreo.service.document.DocOrderBeans;
import com.schneider.oreo.service.document.DocOrderFieldBean;
import com.schneider.oreo.service.document.GetDocumentPage;
import com.schneider.oreo.service.document.GetDocumentPageResponse;
import com.schneider.oreo.service.document.LocaleBean;
import com.schneider.oreo.service.document.ObjectFactory;
import com.schneider.oreo.service.document.OrderType;
import com.schneider.oreo.service.document.PaginationBean;
import com.schneider.oreo.service.document.QueryBean;
import com.schneider.oreo.service.document.ScopeBean;
import com.se.wp.library.bsl.enumerations.Scope;
import com.se.wp.library.constants.Constants;
import com.se.wp.library.utils.EnvironmentUtil;

import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(MockitoExtension.class)
public class BslDocumentServiceTest  {

	List<DocCountByBean> docCountByBeans = new ArrayList<>();
	DocDisplayBeans docDisplayBeans;
	DocDisplayBean docDisplayBean;
	DocOrderBeans docOrderBeans;
	DocOrderBean docOrderBean;
	PaginationBean paginationBean;
	DocCountByBean docCountByBean;
	JAXBElement<GetDocumentPage> jaxbGetDocumentPage;

	@InjectMocks
	BslDocumentService bslDocumentService;

	@Mock
	ScopeBean scopeBean;
	@Mock
	LocaleBean localeBean;
	@Mock
	QueryBean queryBean;
	@Mock
	JAXBElement<GetDocumentPageResponse> getDocumentPageResponse;
	@Mock
	EnvironmentUtil env;
	@Mock
	GetDocumentPageResponse getDocumentPageResponseValue;
	

	@BeforeEach
	public void setUp() throws Exception {
		Jaxb2Marshaller marshaller = new Jaxb2Marshaller();
		marshaller.setContextPath("com.schneider.oreo.service.document");
		bslDocumentService.setMarshaller(marshaller);
		bslDocumentService.setUnmarshaller(marshaller);
		HttpComponentsMessageSender sender = new HttpComponentsMessageSender();
		sender.setConnectionTimeout(Constants.BSL_DOCUMENT_SERVICE_CONNECT_TIME_OUT);
		sender.setReadTimeout(Constants.BSL_DOCUMENT_SERVICE_READ_TIME_OUT);
		bslDocumentService.setMessageSender(sender);
		scopeBean = new ScopeBean();
		localeBean = new LocaleBean();
		queryBean = new QueryBean();
		AttType e = new AttType();
		e.setName("Refnum");
		e.setValue("230");
		queryBean.getAttType().add(e );
		queryBean.getDocTypes().add(1555889l);
		docDisplayBean = new DocDisplayBean();
		docDisplayBeans = new DocDisplayBeans();
		docOrderBeans = new DocOrderBeans();
		docOrderBean = new DocOrderBean();
		paginationBean = new PaginationBean();
		scopeBean.setBrand("Schneider Electric");
		scopeBean.setProject("AllDocuments");
		scopeBean.setCountry("WW");
		localeBean.setIsoCountry("GB");
		localeBean.setIsoLanguage("en");
		docDisplayBean.setField(DocDisplayFieldBean.DOC_DOC_TYPE);
		docDisplayBeans.getDisplayBean().add(docDisplayBean);
		docOrderBean.setField(DocOrderFieldBean.DOC_TYPE_NAME);
		docOrderBean.setType(OrderType.DESC);
		docOrderBeans.getOrderBean().add(docOrderBean);
		paginationBean.setFirstResult(0L);
		paginationBean.setMaxResult(100L);
		env.setPublicBslServiceUrl("http://bsl-pp.dev.schneider-electric.com/bsl-fo-service/DocumentServiceV002");
		getDocumentPageResponseValue=new GetDocumentPageResponse();
		getDocumentPageResponse.setValue(getDocumentPageResponseValue);

	}

	@Test
	public void testGetDocumentPageTest() {
		try {
			Mockito.when(env.getPublicBslServiceUrl()).thenReturn("http://bsl-pp.dev.schneider-electric.com/bsl-fo-service/DocumentServiceV002");
			bslDocumentService.getDocumentPage(scopeBean, localeBean, queryBean, paginationBean, 1000, "99", Scope.GLOBAL);
		} catch (Exception e) {
			fail();
		}
	}

	@Test
	public void testCallWebServiceTest()
	{
		try
		{
			Mockito.when(env.getPublicBslServiceUrl()).thenReturn("http://bsl-pp.dev.schneider-electric.com/bsl-fo-service/DocumentServiceV002");
			ObjectFactory objectFactory = new ObjectFactory();
			GetDocumentPage getDocumentPage = new GetDocumentPage();
			getDocumentPage.setScope(scopeBean);
			getDocumentPage.getLocale().add(localeBean);
			getDocumentPage.setQuery(queryBean);
			getDocumentPage.setMaxCountResult(1000);
			getDocumentPage.setPagination(paginationBean);
			getDocumentPage.setVersion(Long.getLong("99"));
			JAXBElement<GetDocumentPage> jaxbGetDocumentPage = objectFactory.createGetDocumentPage(getDocumentPage);
			bslDocumentService.callWebService(jaxbGetDocumentPage);
		} catch (Exception e) {
			fail();
		}
	}

}
