package com.se.wp.library.rest.bsl.client;

public class MassDownloadConstantsRest {
	public static final String PRODUCT_SERVICE_URL_POSTFIX = "products/search";
	public static final String AUTHORIZATION_HEADER_NAME = "Authorization";
	public static final String DOCUMENT_SERVICE_URL_POSTFIX = "document-pages/search";
	public static final String FIELD_COUNTBY_RANGE = "range";
	public static final String FIRST_RESULT = "0";
	public static final String MAX_RESULT = "1";
	public static final String MAX_COUNT_RESULT = "2000";
	public static final String FIELD_ALL = "all";
	public static final String COUNT_PARAM= "0";
	public static final String DOC_POPULARITY= "doc_popularity";
	public static final String TYPE_ASCENDING = "asc";
	public static final String GUIDED_SEARCH_URL_POSTFIX = "search";
	
	public static final String  DOC_OID="doc_oid";
	public static final String  DOC_REFERENCE="doc_reference";
	public static final String  DOC_VERSION="doc_version";
	public static final String  DOC_LAST_MODIFICATION_DATE="doc_lastModificationDate";
	public static final String  DOC_REVISION="doc_revision";
	public static final String  DOC_FILES="doc_files";
	public static final String  DOC_LOCALES="doc_locales";
	public static final String  DOC_DOCUMENT_TYPE="doc_documentType";
	public static final String  DOC_DOC_TYPE="doc_docType";
	public static final String DOC_DOCUMENT_DATE="doc_documentDate";
	public static final String DOCUMENT_DETAILS_SERVICE_URL_POSTFIX = "documents/search";
	public static final String DOC_DOC_TYPE_GROUPS= "doc_docTypeGroups";
	public static final String DOC_AUDIENCE= "doc_audience";

	public static final String DOC_PUBLICATION_DATE="doc_publicationDate";
	public static final String DOC_CREATION_DATE="doc_creationDate";
	public static final String DOC_NUMBER_OF_PAGE="doc_numberOfPage";
	public static final String DOC_DOC_OWNER="doc_docOwner";
	public static final String DOC_AUTHOR="doc_author";
	public static final String DOC_EXPIRE_DATE="doc_expireDate";
	public static final String DOC_PART_NUMBER="doc_partNumber";
	public static final String DOC_FLIP_FLOP_GENERATED="doc_flipFlopGenerated";
	public static final String DOC_KEYWORDS="doc_keywords";
	public static final String DOC_ATTRIBUTES="doc_attributes";
	public static final String DOC_PRODUCT_REFERENCES="doc_productReferences";
	public static final String DOC_ATTRIBUTE_LISTS="doc_attributeLists";
	public static final String DOC_RANGES="doc_ranges";
	public static final String DOC_PROGRAMS="doc_programs";
	public static final String DOC_DOC_ACCESSES="doc_docAccesses";
	public static final String DOC_BANNER_URL="doc_bannerUrl";
	public static final String DOC_CHANNELS="doc_channels";
	public static final String DOC_FILE_SHA_256="doc_file_sha256";

}



