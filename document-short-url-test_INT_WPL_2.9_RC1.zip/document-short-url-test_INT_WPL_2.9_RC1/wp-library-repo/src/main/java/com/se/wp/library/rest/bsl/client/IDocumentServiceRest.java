package com.se.wp.library.rest.bsl.client;

import org.springframework.http.ResponseEntity;

import com.schneider.rest.document.service.requests.DocumentPage;
import com.schneider.rest.document.service.responses.DocumentPageResponse;

public interface IDocumentServiceRest {
	public ResponseEntity<DocumentPageResponse> getDocumentPageRest(
			DocumentPage documentPage);
}
