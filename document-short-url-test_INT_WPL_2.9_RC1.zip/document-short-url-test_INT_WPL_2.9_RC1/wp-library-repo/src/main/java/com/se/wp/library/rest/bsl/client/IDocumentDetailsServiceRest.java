package com.se.wp.library.rest.bsl.client;

import org.springframework.http.ResponseEntity;

import com.schneider.rest.document.details.service.requests.DocDetailsByRef;
import com.schneider.rest.document.details.service.responses.DocDetailsByRefResponse;

public interface IDocumentDetailsServiceRest {
	public ResponseEntity<DocDetailsByRefResponse> getDocDetailsByRef(
			DocDetailsByRef docDetailsByRef);
}
