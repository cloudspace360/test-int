package com.se.wp.library.rest.cose.apigee;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.stereotype.Component;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import com.se.wp.library.constants.Constants;
import com.se.wp.library.utils.EnvironmentUtil;

@Component
public class ApiGeeCoseAuthTokenService {
	private static final Logger LOGGER = LoggerFactory.getLogger(ApiGeeCoseAuthTokenService.class);

	public String getApiGeeAuthToken(String apiGeeEndpoint, String clientId, String clientSecret) {
		LOGGER.debug("ENTER: ApiGeeCoseAuthTokenService.getApiGeeAuthToken()...");
		LOGGER.debug("apiGeeEndpoint: {}", apiGeeEndpoint);
		LOGGER.debug("clientId: {}", clientId);
		String accessToken = null;
		if (apiGeeEndpoint != null && !apiGeeEndpoint.isEmpty() && clientId != null && !clientId.isEmpty()
				&& clientSecret != null && !clientSecret.isEmpty()) {
			HttpHeaders headers = new HttpHeaders();
			MultiValueMap<String, String> map = new LinkedMultiValueMap<String, String>();
			map.add(Constants.APIGEE_AUTH_TOKEN_SERVICE_PARAM_GRANT_TYPE,
					Constants.APIGEE_AUTH_TOKEN_SERVICE_PARAM_GRANT_TYPE_VALUE);
			map.add(Constants.APIGEE_AUTH_TOKEN_SERVICE_PARAM_CLIENT_ID, clientId);
			map.add(Constants.APIGEE_AUTH_TOKEN_SERVICE_PARAM_CLIENT_SECRET, clientSecret);
			HttpEntity<MultiValueMap<String, String>> requestEntity = new HttpEntity<MultiValueMap<String, String>>(map,
					headers);
			RestTemplate restTemplate = new RestTemplate();
			setTimeout(restTemplate);
			ApiGeeAuthServiceResponse responseEntity = restTemplate.postForObject(apiGeeEndpoint, requestEntity,
					ApiGeeAuthServiceResponse.class);
			if (responseEntity != null) {
				accessToken = responseEntity.getAccessToken();
			}
		}
		LOGGER.debug("apigee access token: {}", accessToken);
		LOGGER.debug("EXIT: ApiGeeAuthTokenService.getApiGeeAuthToken()...");
		return accessToken;
	}

	private void setTimeout(RestTemplate restTemplate) {
		LOGGER.debug("ENTER: ApiGeeAuthTokenService.setTimeout()...");
		SimpleClientHttpRequestFactory rf = (SimpleClientHttpRequestFactory) restTemplate.getRequestFactory();
		try {
			rf.setConnectTimeout(Integer.valueOf(EnvironmentUtil.getIdmsRequestConnectTimeout()));
		} catch (NumberFormatException e) {
			LOGGER.error("Error parsing connectTimeout...");
		}
		try {
			rf.setReadTimeout(Integer.valueOf(EnvironmentUtil.getIdmsRequestReadTimeout()));
		} catch (NumberFormatException e) {
			LOGGER.error("Error parsing readTimeout...");
		}
		LOGGER.debug("EXIT: ApiGeeAuthTokenService.setTimeout()...");
	}
}
