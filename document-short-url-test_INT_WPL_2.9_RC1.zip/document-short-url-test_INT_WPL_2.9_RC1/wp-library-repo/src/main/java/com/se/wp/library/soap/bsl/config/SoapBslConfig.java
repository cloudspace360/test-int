package com.se.wp.library.soap.bsl.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;
import org.springframework.ws.transport.http.HttpComponentsMessageSender;
import com.se.wp.library.constants.Constants;
import com.se.wp.library.soap.bsl.clinet.BslDocumentService;

@Configuration
public class SoapBslConfig {

	@Bean
	public Jaxb2Marshaller documentServiceMarshaller() {
		Jaxb2Marshaller marshaller = new Jaxb2Marshaller();
		marshaller.setContextPath("com.schneider.oreo.service.document");
		return marshaller;
	}

	@Bean
	public BslDocumentService documentServiceClient(Jaxb2Marshaller documentServiceMarshaller,
			HttpComponentsMessageSender documentServicesMessageSender) {
		BslDocumentService client = new BslDocumentService();
		client.setMessageSender(documentServicesMessageSender);
		client.setMarshaller(documentServiceMarshaller);
		client.setUnmarshaller(documentServiceMarshaller);
		return client;
	}

	@Bean
	public HttpComponentsMessageSender documentServicesMessageSender() {
		HttpComponentsMessageSender sender = new HttpComponentsMessageSender();
		sender.setConnectionTimeout(Constants.BSL_DOCUMENT_SERVICE_CONNECT_TIME_OUT);
		sender.setReadTimeout(Constants.BSL_DOCUMENT_SERVICE_READ_TIME_OUT);
		return sender;
	}
}