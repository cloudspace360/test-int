package com.se.wp.library.soap.bsl.clinet;

import com.schneider.oreo.service.document.DocumentPageBean;
import com.schneider.oreo.service.document.PaginationBean;
import com.schneider.oreo.service.document.QueryBean;
import com.se.wp.library.bsl.enumerations.Scope;

public interface IBslDocumentService {

	public DocumentPageBean getDocumentPage(com.schneider.oreo.service.document.ScopeBean scopeBean,
			com.schneider.oreo.service.document.LocaleBean localeBean, QueryBean queryBean,
			PaginationBean paginationBean, int masCountResult, String version, Scope scope);
}
