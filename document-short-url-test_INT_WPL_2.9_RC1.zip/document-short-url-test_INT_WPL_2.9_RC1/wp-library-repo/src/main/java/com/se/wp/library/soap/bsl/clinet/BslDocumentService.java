
package com.se.wp.library.soap.bsl.clinet;

import javax.xml.bind.JAXBElement;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ws.client.core.support.WebServiceGatewaySupport;

import com.schneider.oreo.service.document.DocumentPageBean;
import com.schneider.oreo.service.document.GetDocumentPage;
import com.schneider.oreo.service.document.GetDocumentPageResponse;
import com.schneider.oreo.service.document.LocaleBean;
import com.schneider.oreo.service.document.ObjectFactory;
import com.schneider.oreo.service.document.PaginationBean;
import com.schneider.oreo.service.document.QueryBean;
import com.schneider.oreo.service.document.ScopeBean;
import com.se.wp.library.bsl.enumerations.Scope;
import com.se.wp.library.utils.EnvironmentUtil;

public class BslDocumentService extends WebServiceGatewaySupport implements IBslDocumentService {
	private static final Logger SERVICE_LOGGER = LoggerFactory.getLogger(BslDocumentService.class);

	@Autowired
	private EnvironmentUtil env;

	public Object callWebService(Object request) {
		return getWebServiceTemplate().marshalSendAndReceive(env.getPublicBslServiceUrl(), request);
	}

	@Override
	public DocumentPageBean getDocumentPage(ScopeBean scopeBean, LocaleBean localeBean, QueryBean queryBean,
			PaginationBean paginationBean, int masCountResult, String version, Scope scope) {
		DocumentPageBean documentPageBean = null;
		ObjectFactory objectFactory = new ObjectFactory();
		GetDocumentPage getDocumentPage = new GetDocumentPage();
		getDocumentPage.setScope(scopeBean);
		getDocumentPage.getLocale().add(localeBean);
		getDocumentPage.setQuery(queryBean);
		getDocumentPage.setMaxCountResult(masCountResult);
		getDocumentPage.setPagination(paginationBean);
		getDocumentPage.setVersion(Long.getLong(version));
		JAXBElement<GetDocumentPage> jaxbGetDocumentPage = objectFactory.createGetDocumentPage(getDocumentPage);
		@SuppressWarnings("unchecked")
		JAXBElement<GetDocumentPageResponse> getDocumentPageResponse = (JAXBElement<GetDocumentPageResponse>) callWebService(
				jaxbGetDocumentPage);
		GetDocumentPageResponse response = getDocumentPageResponse.getValue();
		if (response != null) {
			SERVICE_LOGGER.debug("GetDocumentPageResponse received...)");
			documentPageBean = response.getReturn();
		}
		SERVICE_LOGGER.debug("EXIT: SoapDocumentService.getDocumentPage()");
		return documentPageBean;
	}
}
