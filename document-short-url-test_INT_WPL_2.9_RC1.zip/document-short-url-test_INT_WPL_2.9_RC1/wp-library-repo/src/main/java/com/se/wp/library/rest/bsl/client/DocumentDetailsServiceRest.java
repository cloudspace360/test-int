package com.se.wp.library.rest.bsl.client;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.util.StopWatch;
import org.springframework.web.client.HttpServerErrorException.InternalServerError;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestTemplate;

import com.schneider.rest.document.details.service.requests.DocDetailsByRef;
import com.schneider.rest.document.details.service.responses.DocDetailsByRefResponse;
import com.se.wp.library.constants.Constants;
import com.se.wp.library.rest.cose.apigee.ApiGeeCoseAuthTokenService;
import com.se.wp.library.utils.EnvironmentUtil;
import com.se.wp.library.utils.DsuUtil;
@Component
public class DocumentDetailsServiceRest implements IDocumentDetailsServiceRest {
	private static final Logger SERVICE_LOGGER = LoggerFactory.getLogger(DocumentDetailsServiceRest.class);
	@Autowired
	private ApiGeeCoseAuthTokenService apiGeeCoseAuthTokenService;
	@Autowired
	private DsuUtil oneDoewnloadUtil;

	@Override
	public ResponseEntity<DocDetailsByRefResponse> getDocDetailsByRef(
			DocDetailsByRef docDetailsByRef) {
		String apiGeeAuthToken = apiGeeCoseAuthTokenService.getApiGeeAuthToken(EnvironmentUtil.getApiGeeCoseEndpoint(),
				EnvironmentUtil.getApiGeeCoseClientId(), EnvironmentUtil.getApiGeeCoseClientSecret());
		SERVICE_LOGGER.debug("apiGeeAuthToken: {}", apiGeeAuthToken);
		String endpointUrl = EnvironmentUtil.getDocumentRestEndpoint();
		ResponseEntity<DocDetailsByRefResponse> responseEntity = null;
		if (endpointUrl != null && !endpointUrl.isEmpty() && apiGeeAuthToken != null && !apiGeeAuthToken.isEmpty()) {
			endpointUrl = new StringBuilder(endpointUrl).append(Constants.SLASH)
					.append(MassDownloadConstantsRest.DOCUMENT_DETAILS_SERVICE_URL_POSTFIX).toString();
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			headers.add(MassDownloadConstantsRest.AUTHORIZATION_HEADER_NAME, "Bearer " + apiGeeAuthToken);
			HttpEntity<DocDetailsByRef> entity = new HttpEntity<>(
					docDetailsByRef, headers);
			RestTemplate restTemplate = new RestTemplate();
			oneDoewnloadUtil.setTimeout(EnvironmentUtil.getCoseRequestConnectTimeout(),
					EnvironmentUtil.getCoseRequestReadTimeout(), restTemplate);
			final StopWatch stopWatch = new StopWatch();
			try {
				stopWatch.start();
				responseEntity = restTemplate.exchange(endpointUrl, HttpMethod.POST, entity,
						DocDetailsByRefResponse.class);
				stopWatch.stop();

			} catch (HttpStatusCodeException ex) {
				if (ex instanceof InternalServerError) {
					SERVICE_LOGGER.error("InternalServerError: {}", ex.getMessage());
					stopWatch.stop();
				} else {
					stopWatch.stop();
				}
			}
		}
		return responseEntity;
	}
}
