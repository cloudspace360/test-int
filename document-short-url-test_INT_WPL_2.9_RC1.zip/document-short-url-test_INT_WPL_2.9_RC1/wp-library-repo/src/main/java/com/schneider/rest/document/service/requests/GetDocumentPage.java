
package com.schneider.rest.document.service.requests;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.schneider.rest.product.service.requests.Locale;
import com.schneider.rest.product.service.requests.Scope;

@JsonIgnoreProperties(ignoreUnknown = true)
public class GetDocumentPage {

    @JsonProperty("scope")
    private Scope scope;
//    @JsonProperty("locale")
//    private Locale locale;
    @JsonProperty("locale")
    private List<Locale> locale;
    @JsonInclude(Include.NON_NULL)
    @JsonProperty("query")
    private Query query;
    @JsonProperty("countBy")
    private List<CountBy> countBy = new ArrayList<>();
    @JsonInclude(Include.NON_NULL)
    @JsonProperty("order")
    private Order order;
    @JsonInclude(Include.NON_NULL)
    @JsonProperty("display")
    private Display display;
    @JsonProperty("pagination")
    private Pagination pagination;
    @JsonProperty("maxCountResult")
    private int maxCountResult;
    @JsonProperty("version")
    private String version;

    public Scope getScope() {
        return scope;
    }

    public void setScope(Scope scope) {
        this.scope = scope;
    }

//    public Locale getLocale() {
//        return locale;
//    }
//
//    public void setLocale(Locale locale) {
//        this.locale = locale;
//    }
    
    public List<Locale> getLocale() {
        return locale;
    }

    public void setLocale(List<Locale> locale) {
        this.locale = locale;
    }

    public Query getQuery() {
        return query;
    }

    public void setQuery(Query query) {
        this.query = query;
    }

    public List<CountBy> getCountBy() {
        return countBy;
    }

    public void setCountBy(List<CountBy> countBy) {
        this.countBy = countBy;
    }

    public Order getOrder() {
        return order;
    }

    public void setOrder(Order order) {
        this.order = order;
    }

    public Display getDisplay() {
        return display;
    }

    public void setDisplay(Display display) {
        this.display = display;
    }

    public Pagination getPagination() {
        return pagination;
    }

    public void setPagination(Pagination pagination) {
        this.pagination = pagination;
    }

    public int getMaxCountResult() {
        return maxCountResult;
    }

    public void setMaxCountResult(int maxCountResult) {
        this.maxCountResult = maxCountResult;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }
}
