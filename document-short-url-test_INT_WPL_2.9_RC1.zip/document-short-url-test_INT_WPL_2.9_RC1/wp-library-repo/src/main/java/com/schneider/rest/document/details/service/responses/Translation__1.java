
package com.schneider.rest.document.details.service.responses;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Translation__1 {

    @JsonProperty("locale")
    private String locale;
    @JsonProperty("seoAlias")
    private String seoAlias;
    @JsonProperty("title")
    private String title;

    public String getLocale() {
        return locale;
    }

    public void setLocale(String locale) {
        this.locale = locale;
    }

    public String getSeoAlias() {
        return seoAlias;
    }

    public void setSeoAlias(String seoAlias) {
        this.seoAlias = seoAlias;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }
}
