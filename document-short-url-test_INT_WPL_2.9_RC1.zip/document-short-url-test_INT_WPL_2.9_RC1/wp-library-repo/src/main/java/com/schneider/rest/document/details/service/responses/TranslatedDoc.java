package com.schneider.rest.document.details.service.responses;

import java.util.LinkedHashMap;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TranslatedDoc {
    @JsonProperty("reference")
    private String reference;
    @JsonProperty("locales")
    private Locales locales;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new LinkedHashMap<>();
    
    public String getReference() {
        return reference;
    }
    
    public void setReference(String reference) {
        this.reference = reference;
    }
  
    public Locales getLocales() {
        return locales;
    }
  
    public void setLocales(Locales locales) {
        this.locales = locales;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }
}
