
package com.schneider.rest.product.service.responses;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class CommercializedProduct {

	@JsonProperty("brand")
	private String brand;
	@JsonProperty("commStatus")
	private String commStatus;
	@JsonProperty("commercialized")
	private Boolean commercialized;

	public String getBrand() {
		return brand;
	}

	public void setBrand(String brand) {
		this.brand = brand;
	}

	public String getCommStatus() {
		return commStatus;
	}

	public void setCommStatus(String commStatus) {
		this.commStatus = commStatus;
	}

	public Boolean isCommercialized() {
		return commercialized;
	}

	public void setCommercialized(Boolean commercialized) {
		this.commercialized = commercialized;
	}
}
