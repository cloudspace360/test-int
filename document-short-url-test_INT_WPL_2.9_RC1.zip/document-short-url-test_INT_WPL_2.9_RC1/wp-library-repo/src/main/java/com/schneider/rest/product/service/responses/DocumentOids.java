
package com.schneider.rest.product.service.responses;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class DocumentOids {

	@JsonProperty("oid")
	private List<String> oid = new ArrayList<>();

	public List<String> getOid() {
		return oid;
	}

	public void setOid(List<String> oid) {
		this.oid = oid;
	}
}
