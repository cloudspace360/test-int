
package com.schneider.oreo.service.document;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for docDisplayFieldBean.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="docDisplayFieldBean"&gt;
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *     &lt;enumeration value="doc_id"/&gt;
 *     &lt;enumeration value="doc_oid"/&gt;
 *     &lt;enumeration value="doc_reference"/&gt;
 *     &lt;enumeration value="doc_version"/&gt;
 *     &lt;enumeration value="doc_lastModificationDate"/&gt;
 *     &lt;enumeration value="doc_publicationDate"/&gt;
 *     &lt;enumeration value="doc_documentDate"/&gt;
 *     &lt;enumeration value="doc_creationDate"/&gt;
 *     &lt;enumeration value="doc_revision"/&gt;
 *     &lt;enumeration value="doc_numberOfPage"/&gt;
 *     &lt;enumeration value="doc_docOwner"/&gt;
 *     &lt;enumeration value="doc_author"/&gt;
 *     &lt;enumeration value="doc_expireDate"/&gt;
 *     &lt;enumeration value="doc_partNumber"/&gt;
 *     &lt;enumeration value="doc_flipFlopGenerated"/&gt;
 *     &lt;enumeration value="doc_audience"/&gt;
 *     &lt;enumeration value="doc_keywords"/&gt;
 *     &lt;enumeration value="doc_attributes"/&gt;
 *     &lt;enumeration value="doc_files"/&gt;
 *     &lt;enumeration value="doc_locales"/&gt;
 *     &lt;enumeration value="doc_documentType"/&gt;
 *     &lt;enumeration value="doc_productReferences"/&gt;
 *     &lt;enumeration value="doc_attributeLists"/&gt;
 *     &lt;enumeration value="doc_docTypeGroups"/&gt;
 *     &lt;enumeration value="doc_docType"/&gt;
 *     &lt;enumeration value="doc_ranges"/&gt;
 *     &lt;enumeration value="doc_programs"/&gt;
 *     &lt;enumeration value="doc_docAccesses"/&gt;
 *     &lt;enumeration value="doc_bannerUrl"/&gt;
 *     &lt;enumeration value="doc_file_sha256"/&gt;
 *   &lt;/restriction&gt;
 * &lt;/simpleType&gt;
 * </pre>
 * 
 */
@XmlType(name = "docDisplayFieldBean")
@XmlEnum
public enum DocDisplayFieldBean {

    @XmlEnumValue("doc_id")
    DOC_ID("doc_id"),
    @XmlEnumValue("doc_oid")
    DOC_OID("doc_oid"),
    @XmlEnumValue("doc_reference")
    DOC_REFERENCE("doc_reference"),
    @XmlEnumValue("doc_version")
    DOC_VERSION("doc_version"),
    @XmlEnumValue("doc_lastModificationDate")
    DOC_LAST_MODIFICATION_DATE("doc_lastModificationDate"),
    @XmlEnumValue("doc_publicationDate")
    DOC_PUBLICATION_DATE("doc_publicationDate"),
    @XmlEnumValue("doc_documentDate")
    DOC_DOCUMENT_DATE("doc_documentDate"),
    @XmlEnumValue("doc_creationDate")
    DOC_CREATION_DATE("doc_creationDate"),
    @XmlEnumValue("doc_revision")
    DOC_REVISION("doc_revision"),
    @XmlEnumValue("doc_numberOfPage")
    DOC_NUMBER_OF_PAGE("doc_numberOfPage"),
    @XmlEnumValue("doc_docOwner")
    DOC_DOC_OWNER("doc_docOwner"),
    @XmlEnumValue("doc_author")
    DOC_AUTHOR("doc_author"),
    @XmlEnumValue("doc_expireDate")
    DOC_EXPIRE_DATE("doc_expireDate"),
    @XmlEnumValue("doc_partNumber")
    DOC_PART_NUMBER("doc_partNumber"),
    @XmlEnumValue("doc_flipFlopGenerated")
    DOC_FLIP_FLOP_GENERATED("doc_flipFlopGenerated"),
    @XmlEnumValue("doc_audience")
    DOC_AUDIENCE("doc_audience"),
    @XmlEnumValue("doc_keywords")
    DOC_KEYWORDS("doc_keywords"),
    @XmlEnumValue("doc_attributes")
    DOC_ATTRIBUTES("doc_attributes"),
    @XmlEnumValue("doc_files")
    DOC_FILES("doc_files"),
    @XmlEnumValue("doc_locales")
    DOC_LOCALES("doc_locales"),
    @XmlEnumValue("doc_documentType")
    DOC_DOCUMENT_TYPE("doc_documentType"),
    @XmlEnumValue("doc_productReferences")
    DOC_PRODUCT_REFERENCES("doc_productReferences"),
    @XmlEnumValue("doc_attributeLists")
    DOC_ATTRIBUTE_LISTS("doc_attributeLists"),
    @XmlEnumValue("doc_docTypeGroups")
    DOC_DOC_TYPE_GROUPS("doc_docTypeGroups"),
    @XmlEnumValue("doc_docType")
    DOC_DOC_TYPE("doc_docType"),
    @XmlEnumValue("doc_ranges")
    DOC_RANGES("doc_ranges"),
    @XmlEnumValue("doc_programs")
    DOC_PROGRAMS("doc_programs"),
    @XmlEnumValue("doc_docAccesses")
    DOC_DOC_ACCESSES("doc_docAccesses"),
    @XmlEnumValue("doc_bannerUrl")
    DOC_BANNER_URL("doc_bannerUrl"),
    @XmlEnumValue("doc_file_sha256")
    DOC_FILE_SHA_256("doc_file_sha256");
    private final String value;

    DocDisplayFieldBean(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static DocDisplayFieldBean fromValue(String v) {
        for (DocDisplayFieldBean c: DocDisplayFieldBean.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
