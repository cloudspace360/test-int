
package com.schneider.rest.product.service.responses;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Picture {

    @JsonProperty("id")
    private Long id;
    @JsonProperty("pictureDocumentOid")
    private Long pictureDocumentOid;
    @JsonProperty("pictureDocumentReference")
    private String pictureDocumentReference;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getPictureDocumentOid() {
        return pictureDocumentOid;
    }

    public void setPictureDocumentOid(Long pictureDocumentOid) {
        this.pictureDocumentOid = pictureDocumentOid;
    }

    public String getPictureDocumentReference() {
        return pictureDocumentReference;
    }

    public void setPictureDocumentReference(String pictureDocumentReference) {
        this.pictureDocumentReference = pictureDocumentReference;
    }
}
