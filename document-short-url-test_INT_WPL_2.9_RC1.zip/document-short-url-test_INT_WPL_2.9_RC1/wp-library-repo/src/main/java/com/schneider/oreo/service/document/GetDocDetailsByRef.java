
package com.schneider.oreo.service.document;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for getDocDetailsByRef complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="getDocDetailsByRef"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="applicationToken" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="scope" type="{http://document.service.oreo.schneider.com/}scopeBean"/&gt;
 *         &lt;element name="locale" type="{http://document.service.oreo.schneider.com/}localeBean"/&gt;
 *         &lt;element name="display" type="{http://document.service.oreo.schneider.com/}docDisplayBeans" minOccurs="0"/&gt;
 *         &lt;element name="docReference" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="scopeIndependant" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/&gt;
 *         &lt;element name="version" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "getDocDetailsByRef", propOrder = {
    "applicationToken",
    "scope",
    "locale",
    "display",
    "docReference",
    "scopeIndependant",
    "version"
})
public class GetDocDetailsByRef {

    protected String applicationToken;
    @XmlElement(required = true)
    protected ScopeBean scope;
    @XmlElement(required = true)
    protected LocaleBean locale;
    protected DocDisplayBeans display;
    @XmlElement(required = true)
    protected String docReference;
    protected Boolean scopeIndependant;
    protected Long version;

    /**
     * Gets the value of the applicationToken property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getApplicationToken() {
        return applicationToken;
    }

    /**
     * Sets the value of the applicationToken property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setApplicationToken(String value) {
        this.applicationToken = value;
    }

    /**
     * Gets the value of the scope property.
     * 
     * @return
     *     possible object is
     *     {@link ScopeBean }
     *     
     */
    public ScopeBean getScope() {
        return scope;
    }

    /**
     * Sets the value of the scope property.
     * 
     * @param value
     *     allowed object is
     *     {@link ScopeBean }
     *     
     */
    public void setScope(ScopeBean value) {
        this.scope = value;
    }

    /**
     * Gets the value of the locale property.
     * 
     * @return
     *     possible object is
     *     {@link LocaleBean }
     *     
     */
    public LocaleBean getLocale() {
        return locale;
    }

    /**
     * Sets the value of the locale property.
     * 
     * @param value
     *     allowed object is
     *     {@link LocaleBean }
     *     
     */
    public void setLocale(LocaleBean value) {
        this.locale = value;
    }

    /**
     * Gets the value of the display property.
     * 
     * @return
     *     possible object is
     *     {@link DocDisplayBeans }
     *     
     */
    public DocDisplayBeans getDisplay() {
        return display;
    }

    /**
     * Sets the value of the display property.
     * 
     * @param value
     *     allowed object is
     *     {@link DocDisplayBeans }
     *     
     */
    public void setDisplay(DocDisplayBeans value) {
        this.display = value;
    }

    /**
     * Gets the value of the docReference property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDocReference() {
        return docReference;
    }

    /**
     * Sets the value of the docReference property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDocReference(String value) {
        this.docReference = value;
    }

    /**
     * Gets the value of the scopeIndependant property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isScopeIndependant() {
        return scopeIndependant;
    }

    /**
     * Sets the value of the scopeIndependant property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setScopeIndependant(Boolean value) {
        this.scopeIndependant = value;
    }

    /**
     * Gets the value of the version property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getVersion() {
        return version;
    }

    /**
     * Sets the value of the version property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setVersion(Long value) {
        this.version = value;
    }

}
