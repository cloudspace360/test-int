
package com.schneider.rest.product.service.requests;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class ProductDetailByCommercialRef {

    @JsonProperty("getProductDetailByCommercialRef")
    private GetProductDetailByCommercialRef getProductDetailByCommercialRef;

    public GetProductDetailByCommercialRef getGetProductDetailByCommercialRef() {
        return getProductDetailByCommercialRef;
    }

    public void setGetProductDetailByCommercialRef(GetProductDetailByCommercialRef getProductDetailByCommercialRef) {
        this.getProductDetailByCommercialRef = getProductDetailByCommercialRef;
    }
}
