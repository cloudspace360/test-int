@javax.xml.bind.annotation.XmlSchema(namespace = "http://document.service.oreo.schneider.com/")
package com.schneider.oreo.service.document;
