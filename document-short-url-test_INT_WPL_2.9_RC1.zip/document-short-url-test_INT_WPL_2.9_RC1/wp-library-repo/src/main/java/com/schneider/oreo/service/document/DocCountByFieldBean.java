
package com.schneider.oreo.service.document;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for docCountByFieldBean.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="docCountByFieldBean"&gt;
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *     &lt;enumeration value="range"/&gt;
 *     &lt;enumeration value="language"/&gt;
 *     &lt;enumeration value="docType"/&gt;
 *     &lt;enumeration value="docTypeGroup"/&gt;
 *     &lt;enumeration value="attType"/&gt;
 *     &lt;enumeration value="attributeList"/&gt;
 *     &lt;enumeration value="attListType"/&gt;
 *     &lt;enumeration value="attribute"/&gt;
 *     &lt;enumeration value="category"/&gt;
 *     &lt;enumeration value="segment"/&gt;
 *     &lt;enumeration value="application"/&gt;
 *     &lt;enumeration value="domain"/&gt;
 *     &lt;enumeration value="brand"/&gt;
 *     &lt;enumeration value="fileExtension"/&gt;
 *     &lt;enumeration value="masterRange"/&gt;
 *     &lt;enumeration value="all"/&gt;
 *   &lt;/restriction&gt;
 * &lt;/simpleType&gt;
 * </pre>
 * 
 */
@XmlType(name = "docCountByFieldBean")
@XmlEnum
public enum DocCountByFieldBean {

    @XmlEnumValue("range")
    RANGE("range"),
    @XmlEnumValue("language")
    LANGUAGE("language"),
    @XmlEnumValue("docType")
    DOC_TYPE("docType"),
    @XmlEnumValue("docTypeGroup")
    DOC_TYPE_GROUP("docTypeGroup"),
    @XmlEnumValue("attType")
    ATT_TYPE("attType"),
    @XmlEnumValue("attributeList")
    ATTRIBUTE_LIST("attributeList"),
    @XmlEnumValue("attListType")
    ATT_LIST_TYPE("attListType"),
    @XmlEnumValue("attribute")
    ATTRIBUTE("attribute"),
    @XmlEnumValue("category")
    CATEGORY("category"),
    @XmlEnumValue("segment")
    SEGMENT("segment"),
    @XmlEnumValue("application")
    APPLICATION("application"),
    @XmlEnumValue("domain")
    DOMAIN("domain"),
    @XmlEnumValue("brand")
    BRAND("brand"),
    @XmlEnumValue("fileExtension")
    FILE_EXTENSION("fileExtension"),
    @XmlEnumValue("masterRange")
    MASTER_RANGE("masterRange"),
    @XmlEnumValue("all")
    ALL("all");
    private final String value;

    DocCountByFieldBean(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static DocCountByFieldBean fromValue(String v) {
        for (DocCountByFieldBean c: DocCountByFieldBean.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
