
package com.schneider.rest.document.details.service.responses;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.schneider.rest.document.service.responses.Translations;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Channel {

	@JsonProperty("code")
	private String code;
	@JsonProperty("key")
	private String key;
	@JsonProperty("oid")
	private Long oid;
	@JsonProperty("parentCode")
	private String parentCode;
	@JsonProperty("parentId")
	private String parentId;
	@JsonProperty("parentKey")
	private String parentKey;
	@JsonProperty("parentTranslations")
	private ParentTranslations parentTranslations;
	@JsonProperty("translations")
	private Translations translations;

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}

	public Long getOid() {
		return oid;
	}

	public void setOid(Long oid) {
		this.oid = oid;
	}

	public String getParentCode() {
		return parentCode;
	}

	public void setParentCode(String parentCode) {
		this.parentCode = parentCode;
	}

	public String getParentId() {
		return parentId;
	}

	public void setParentId(String parentId) {
		this.parentId = parentId;
	}

	public String getParentKey() {
		return parentKey;
	}

	public void setParentKey(String parentKey) {
		this.parentKey = parentKey;
	}

	public ParentTranslations getParentTranslations() {
		return parentTranslations;
	}

	public void setParentTranslations(ParentTranslations parentTranslations) {
		this.parentTranslations = parentTranslations;
	}

	public Translations getTranslations() {
		return translations;
	}

	public void setTranslations(Translations translations) {
		this.translations = translations;
	}
}
