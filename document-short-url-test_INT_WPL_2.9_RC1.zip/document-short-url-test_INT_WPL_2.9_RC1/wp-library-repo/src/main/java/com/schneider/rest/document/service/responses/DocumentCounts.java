
package com.schneider.rest.document.service.responses;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class DocumentCounts {

    @JsonProperty("documentCount")
    private List<DocumentCount> documentCount = new ArrayList<>();

    public List<DocumentCount> getDocumentCount() {
        return documentCount;
    }
    public void setDocumentCount(List<DocumentCount> documentCount) {
        this.documentCount = documentCount;
    }
}
