
package com.schneider.rest.document.service.responses;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class ProductReference {

	@JsonProperty("commRef")
	private String commRef;
	@JsonProperty("main")
	private Boolean main;
	@JsonProperty("alternative")
	private Boolean alternative;

	public String getCommRef() {
		return commRef;
	}

	public void setCommRef(String commRef) {
		this.commRef = commRef;
	}

	public ProductReference withCommRef(String commRef) {
		this.commRef = commRef;
		return this;
	}
}
