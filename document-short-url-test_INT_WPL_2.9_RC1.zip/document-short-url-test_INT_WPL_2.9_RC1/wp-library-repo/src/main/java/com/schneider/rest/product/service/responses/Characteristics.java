
package com.schneider.rest.product.service.responses;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Characteristics {

    @JsonProperty("characteristic")
    private List<Characteristic> characteristic = new ArrayList<>();

    public List<Characteristic> getCharacteristic() {
        return characteristic;
    }

    public void setCharacteristic(List<Characteristic> characteristic) {
        this.characteristic = characteristic;
    }

    public Characteristics withCharacteristic(List<Characteristic> characteristic) {
        this.characteristic = characteristic;
        return this;
    }
}
