
package com.schneider.rest.document.details.service.requests;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class DocDetailsByRef {

    @JsonProperty("getDocDetailsByRef")
    private GetDocDetailsByRef getDocDetailsByRef;

    public GetDocDetailsByRef getGetDocDetailsByRef() {
        return getDocDetailsByRef;
    }

    public void setGetDocDetailsByRef(GetDocDetailsByRef getDocDetailsByRef) {
        this.getDocDetailsByRef = getDocDetailsByRef;
    }
}
