
package com.schneider.oreo.service.document;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.schneider.oreo.service.document package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _AttListType_QNAME = new QName("http://document.service.oreo.schneider.com/", "attListType");
    private final static QName _AttType_QNAME = new QName("http://document.service.oreo.schneider.com/", "attType");
    private final static QName _DocAccess_QNAME = new QName("http://document.service.oreo.schneider.com/", "docAccess");
    private final static QName _DocumentBeanV001_QNAME = new QName("http://document.service.oreo.schneider.com/", "documentBeanV001");
    private final static QName _DocumentBeanV002_QNAME = new QName("http://document.service.oreo.schneider.com/", "documentBeanV002");
    private final static QName _DocumentCountBean_QNAME = new QName("http://document.service.oreo.schneider.com/", "documentCountBean");
    private final static QName _DocumentCountByRangeBean_QNAME = new QName("http://document.service.oreo.schneider.com/", "documentCountByRangeBean");
    private final static QName _DocumentPageCountBean_QNAME = new QName("http://document.service.oreo.schneider.com/", "documentPageCountBean");
    private final static QName _DocumentPageDocumentBean_QNAME = new QName("http://document.service.oreo.schneider.com/", "documentPageDocumentBean");
    private final static QName _File_QNAME = new QName("http://document.service.oreo.schneider.com/", "file");
    private final static QName _GetDocDetails_QNAME = new QName("http://document.service.oreo.schneider.com/", "getDocDetails");
    private final static QName _GetDocDetailsByRef_QNAME = new QName("http://document.service.oreo.schneider.com/", "getDocDetailsByRef");
    private final static QName _GetDocDetailsByRefResponse_QNAME = new QName("http://document.service.oreo.schneider.com/", "getDocDetailsByRefResponse");
    private final static QName _GetDocDetailsResponse_QNAME = new QName("http://document.service.oreo.schneider.com/", "getDocDetailsResponse");
    private final static QName _GetDocumentCount_QNAME = new QName("http://document.service.oreo.schneider.com/", "getDocumentCount");
    private final static QName _GetDocumentCountByRange_QNAME = new QName("http://document.service.oreo.schneider.com/", "getDocumentCountByRange");
    private final static QName _GetDocumentCountByRangeResponse_QNAME = new QName("http://document.service.oreo.schneider.com/", "getDocumentCountByRangeResponse");
    private final static QName _GetDocumentCountResponse_QNAME = new QName("http://document.service.oreo.schneider.com/", "getDocumentCountResponse");
    private final static QName _GetDocumentList_QNAME = new QName("http://document.service.oreo.schneider.com/", "getDocumentList");
    private final static QName _GetDocumentListResponse_QNAME = new QName("http://document.service.oreo.schneider.com/", "getDocumentListResponse");
    private final static QName _GetDocumentPage_QNAME = new QName("http://document.service.oreo.schneider.com/", "getDocumentPage");
    private final static QName _GetDocumentPageResponse_QNAME = new QName("http://document.service.oreo.schneider.com/", "getDocumentPageResponse");
    private final static QName _GetScopingLanguages_QNAME = new QName("http://document.service.oreo.schneider.com/", "getScopingLanguages");
    private final static QName _GetScopingLanguagesResponse_QNAME = new QName("http://document.service.oreo.schneider.com/", "getScopingLanguagesResponse");
    private final static QName _Locale_QNAME = new QName("http://document.service.oreo.schneider.com/", "locale");
    private final static QName _LocaleBean_QNAME = new QName("http://document.service.oreo.schneider.com/", "localeBean");
    private final static QName _Program_QNAME = new QName("http://document.service.oreo.schneider.com/", "program");
    private final static QName _QueryBean_QNAME = new QName("http://document.service.oreo.schneider.com/", "queryBean");
    private final static QName _QueryItem_QNAME = new QName("http://document.service.oreo.schneider.com/", "queryItem");
    private final static QName _RangeBeanV001_QNAME = new QName("http://document.service.oreo.schneider.com/", "rangeBeanV001");
    private final static QName _ScopeBean_QNAME = new QName("http://document.service.oreo.schneider.com/", "scopeBean");
    private final static QName _ScopingLanguageBean_QNAME = new QName("http://document.service.oreo.schneider.com/", "scopingLanguageBean");
    private final static QName _TranslatedBean_QNAME = new QName("http://document.service.oreo.schneider.com/", "translatedBean");
    private final static QName _DocumentServiceException_QNAME = new QName("http://document.service.oreo.schneider.com/", "DocumentServiceException");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.schneider.oreo.service.document
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link DocumentPageBean }
     * 
     */
    public DocumentPageBean createDocumentPageBean() {
        return new DocumentPageBean();
    }

    /**
     * Create an instance of {@link ScopingLanguageBean }
     * 
     */
    public ScopingLanguageBean createScopingLanguageBean() {
        return new ScopingLanguageBean();
    }

    /**
     * Create an instance of {@link QueryBean }
     * 
     */
    public QueryBean createQueryBean() {
        return new QueryBean();
    }

    /**
     * Create an instance of {@link DocumentPageDocumentBean }
     * 
     */
    public DocumentPageDocumentBean createDocumentPageDocumentBean() {
        return new DocumentPageDocumentBean();
    }

    /**
     * Create an instance of {@link DocumentBeanV001 }
     * 
     */
    public DocumentBeanV001 createDocumentBeanV001() {
        return new DocumentBeanV001();
    }

    /**
     * Create an instance of {@link AttListType }
     * 
     */
    public AttListType createAttListType() {
        return new AttListType();
    }

    /**
     * Create an instance of {@link AttType }
     * 
     */
    public AttType createAttType() {
        return new AttType();
    }

    /**
     * Create an instance of {@link DocAccessBean }
     * 
     */
    public DocAccessBean createDocAccessBean() {
        return new DocAccessBean();
    }

    /**
     * Create an instance of {@link DocumentBeanV002 }
     * 
     */
    public DocumentBeanV002 createDocumentBeanV002() {
        return new DocumentBeanV002();
    }

    /**
     * Create an instance of {@link DocumentCountBean }
     * 
     */
    public DocumentCountBean createDocumentCountBean() {
        return new DocumentCountBean();
    }

    /**
     * Create an instance of {@link DocumentCountByRangeBean }
     * 
     */
    public DocumentCountByRangeBean createDocumentCountByRangeBean() {
        return new DocumentCountByRangeBean();
    }

    /**
     * Create an instance of {@link DocumentPageCountBean }
     * 
     */
    public DocumentPageCountBean createDocumentPageCountBean() {
        return new DocumentPageCountBean();
    }

    /**
     * Create an instance of {@link GetDocDetails }
     * 
     */
    public GetDocDetails createGetDocDetails() {
        return new GetDocDetails();
    }

    /**
     * Create an instance of {@link GetDocDetailsByRef }
     * 
     */
    public GetDocDetailsByRef createGetDocDetailsByRef() {
        return new GetDocDetailsByRef();
    }

    /**
     * Create an instance of {@link GetDocDetailsByRefResponse }
     * 
     */
    public GetDocDetailsByRefResponse createGetDocDetailsByRefResponse() {
        return new GetDocDetailsByRefResponse();
    }

    /**
     * Create an instance of {@link GetDocDetailsResponse }
     * 
     */
    public GetDocDetailsResponse createGetDocDetailsResponse() {
        return new GetDocDetailsResponse();
    }

    /**
     * Create an instance of {@link GetDocumentCount }
     * 
     */
    public GetDocumentCount createGetDocumentCount() {
        return new GetDocumentCount();
    }

    /**
     * Create an instance of {@link GetDocumentCountByRange }
     * 
     */
    public GetDocumentCountByRange createGetDocumentCountByRange() {
        return new GetDocumentCountByRange();
    }

    /**
     * Create an instance of {@link GetDocumentCountByRangeResponse }
     * 
     */
    public GetDocumentCountByRangeResponse createGetDocumentCountByRangeResponse() {
        return new GetDocumentCountByRangeResponse();
    }

    /**
     * Create an instance of {@link GetDocumentCountResponse }
     * 
     */
    public GetDocumentCountResponse createGetDocumentCountResponse() {
        return new GetDocumentCountResponse();
    }

    /**
     * Create an instance of {@link GetDocumentList }
     * 
     */
    public GetDocumentList createGetDocumentList() {
        return new GetDocumentList();
    }

    /**
     * Create an instance of {@link GetDocumentListResponse }
     * 
     */
    public GetDocumentListResponse createGetDocumentListResponse() {
        return new GetDocumentListResponse();
    }

    /**
     * Create an instance of {@link GetDocumentPage }
     * 
     */
    public GetDocumentPage createGetDocumentPage() {
        return new GetDocumentPage();
    }

    /**
     * Create an instance of {@link GetDocumentPageResponse }
     * 
     */
    public GetDocumentPageResponse createGetDocumentPageResponse() {
        return new GetDocumentPageResponse();
    }

    /**
     * Create an instance of {@link GetScopingLanguages }
     * 
     */
    public GetScopingLanguages createGetScopingLanguages() {
        return new GetScopingLanguages();
    }

    /**
     * Create an instance of {@link GetScopingLanguagesResponse }
     * 
     */
    public GetScopingLanguagesResponse createGetScopingLanguagesResponse() {
        return new GetScopingLanguagesResponse();
    }

    /**
     * Create an instance of {@link Locale }
     * 
     */
    public Locale createLocale() {
        return new Locale();
    }

    /**
     * Create an instance of {@link LocaleBean }
     * 
     */
    public LocaleBean createLocaleBean() {
        return new LocaleBean();
    }

    /**
     * Create an instance of {@link ProgramBean }
     * 
     */
    public ProgramBean createProgramBean() {
        return new ProgramBean();
    }

    /**
     * Create an instance of {@link QueryItemBean }
     * 
     */
    public QueryItemBean createQueryItemBean() {
        return new QueryItemBean();
    }

    /**
     * Create an instance of {@link RangeBeanV001 }
     * 
     */
    public RangeBeanV001 createRangeBeanV001() {
        return new RangeBeanV001();
    }

    /**
     * Create an instance of {@link ScopeBean }
     * 
     */
    public ScopeBean createScopeBean() {
        return new ScopeBean();
    }

    /**
     * Create an instance of {@link TranslatedBean }
     * 
     */
    public TranslatedBean createTranslatedBean() {
        return new TranslatedBean();
    }

    /**
     * Create an instance of {@link DocumentServiceException }
     * 
     */
    public DocumentServiceException createDocumentServiceException() {
        return new DocumentServiceException();
    }

    /**
     * Create an instance of {@link DocDisplayBeans }
     * 
     */
    public DocDisplayBeans createDocDisplayBeans() {
        return new DocDisplayBeans();
    }

    /**
     * Create an instance of {@link DocDisplayBean }
     * 
     */
    public DocDisplayBean createDocDisplayBean() {
        return new DocDisplayBean();
    }

    /**
     * Create an instance of {@link FileContentBean }
     * 
     */
    public FileContentBean createFileContentBean() {
        return new FileContentBean();
    }

    /**
     * Create an instance of {@link AttributeListBean }
     * 
     */
    public AttributeListBean createAttributeListBean() {
        return new AttributeListBean();
    }

    /**
     * Create an instance of {@link AttributeBean }
     * 
     */
    public AttributeBean createAttributeBean() {
        return new AttributeBean();
    }

    /**
     * Create an instance of {@link AudienceBean }
     * 
     */
    public AudienceBean createAudienceBean() {
        return new AudienceBean();
    }

    /**
     * Create an instance of {@link DocumentTypeGroupBean }
     * 
     */
    public DocumentTypeGroupBean createDocumentTypeGroupBean() {
        return new DocumentTypeGroupBean();
    }

    /**
     * Create an instance of {@link DocumentTypeBean }
     * 
     */
    public DocumentTypeBean createDocumentTypeBean() {
        return new DocumentTypeBean();
    }

    /**
     * Create an instance of {@link FileBeanV001 }
     * 
     */
    public FileBeanV001 createFileBeanV001() {
        return new FileBeanV001();
    }

    /**
     * Create an instance of {@link FileBean }
     * 
     */
    public FileBean createFileBean() {
        return new FileBean();
    }

    /**
     * Create an instance of {@link SearchBeans }
     * 
     */
    public SearchBeans createSearchBeans() {
        return new SearchBeans();
    }

    /**
     * Create an instance of {@link SearchBean }
     * 
     */
    public SearchBean createSearchBean() {
        return new SearchBean();
    }

    /**
     * Create an instance of {@link DocCountByBean }
     * 
     */
    public DocCountByBean createDocCountByBean() {
        return new DocCountByBean();
    }

    /**
     * Create an instance of {@link DocOrderBeans }
     * 
     */
    public DocOrderBeans createDocOrderBeans() {
        return new DocOrderBeans();
    }

    /**
     * Create an instance of {@link DocOrderBean }
     * 
     */
    public DocOrderBean createDocOrderBean() {
        return new DocOrderBean();
    }

    /**
     * Create an instance of {@link OrderBean }
     * 
     */
    public OrderBean createOrderBean() {
        return new OrderBean();
    }

    /**
     * Create an instance of {@link DocOrderMappingBean }
     * 
     */
    public DocOrderMappingBean createDocOrderMappingBean() {
        return new DocOrderMappingBean();
    }

    /**
     * Create an instance of {@link DocEntry }
     * 
     */
    public DocEntry createDocEntry() {
        return new DocEntry();
    }

    /**
     * Create an instance of {@link PaginationBean }
     * 
     */
    public PaginationBean createPaginationBean() {
        return new PaginationBean();
    }

    /**
     * Create an instance of {@link DocumentPageCountResult }
     * 
     */
    public DocumentPageCountResult createDocumentPageCountResult() {
        return new DocumentPageCountResult();
    }

    /**
     * Create an instance of {@link DocumentPageAttributeListBean }
     * 
     */
    public DocumentPageAttributeListBean createDocumentPageAttributeListBean() {
        return new DocumentPageAttributeListBean();
    }

    /**
     * Create an instance of {@link DocumentPageAttributeBean }
     * 
     */
    public DocumentPageAttributeBean createDocumentPageAttributeBean() {
        return new DocumentPageAttributeBean();
    }

    /**
     * Create an instance of {@link BslObjectBean }
     * 
     */
    public BslObjectBean createBslObjectBean() {
        return new BslObjectBean();
    }

    /**
     * Create an instance of {@link DocumentPageBean.DocumentCounts }
     * 
     */
    public DocumentPageBean.DocumentCounts createDocumentPageBeanDocumentCounts() {
        return new DocumentPageBean.DocumentCounts();
    }

    /**
     * Create an instance of {@link DocumentPageBean.Documents }
     * 
     */
    public DocumentPageBean.Documents createDocumentPageBeanDocuments() {
        return new DocumentPageBean.Documents();
    }

    /**
     * Create an instance of {@link ScopingLanguageBean.LocaleList }
     * 
     */
    public ScopingLanguageBean.LocaleList createScopingLanguageBeanLocaleList() {
        return new ScopingLanguageBean.LocaleList();
    }

    /**
     * Create an instance of {@link QueryBean.DocAccesses }
     * 
     */
    public QueryBean.DocAccesses createQueryBeanDocAccesses() {
        return new QueryBean.DocAccesses();
    }

    /**
     * Create an instance of {@link DocumentPageDocumentBean.AttributeLists }
     * 
     */
    public DocumentPageDocumentBean.AttributeLists createDocumentPageDocumentBeanAttributeLists() {
        return new DocumentPageDocumentBean.AttributeLists();
    }

    /**
     * Create an instance of {@link DocumentPageDocumentBean.Attributes }
     * 
     */
    public DocumentPageDocumentBean.Attributes createDocumentPageDocumentBeanAttributes() {
        return new DocumentPageDocumentBean.Attributes();
    }

    /**
     * Create an instance of {@link DocumentPageDocumentBean.DocTypeGroups }
     * 
     */
    public DocumentPageDocumentBean.DocTypeGroups createDocumentPageDocumentBeanDocTypeGroups() {
        return new DocumentPageDocumentBean.DocTypeGroups();
    }

    /**
     * Create an instance of {@link DocumentPageDocumentBean.Files }
     * 
     */
    public DocumentPageDocumentBean.Files createDocumentPageDocumentBeanFiles() {
        return new DocumentPageDocumentBean.Files();
    }

    /**
     * Create an instance of {@link DocumentPageDocumentBean.Locales }
     * 
     */
    public DocumentPageDocumentBean.Locales createDocumentPageDocumentBeanLocales() {
        return new DocumentPageDocumentBean.Locales();
    }

    /**
     * Create an instance of {@link DocumentPageDocumentBean.ProductReferences }
     * 
     */
    public DocumentPageDocumentBean.ProductReferences createDocumentPageDocumentBeanProductReferences() {
        return new DocumentPageDocumentBean.ProductReferences();
    }

    /**
     * Create an instance of {@link DocumentPageDocumentBean.Ranges }
     * 
     */
    public DocumentPageDocumentBean.Ranges createDocumentPageDocumentBeanRanges() {
        return new DocumentPageDocumentBean.Ranges();
    }

    /**
     * Create an instance of {@link DocumentBeanV001 .AttributeLists }
     * 
     */
    public DocumentBeanV001 .AttributeLists createDocumentBeanV001AttributeLists() {
        return new DocumentBeanV001 .AttributeLists();
    }

    /**
     * Create an instance of {@link DocumentBeanV001 .Attributes }
     * 
     */
    public DocumentBeanV001 .Attributes createDocumentBeanV001Attributes() {
        return new DocumentBeanV001 .Attributes();
    }

    /**
     * Create an instance of {@link DocumentBeanV001 .DocAccesses }
     * 
     */
    public DocumentBeanV001 .DocAccesses createDocumentBeanV001DocAccesses() {
        return new DocumentBeanV001 .DocAccesses();
    }

    /**
     * Create an instance of {@link DocumentBeanV001 .DocTypeGroups }
     * 
     */
    public DocumentBeanV001 .DocTypeGroups createDocumentBeanV001DocTypeGroups() {
        return new DocumentBeanV001 .DocTypeGroups();
    }

    /**
     * Create an instance of {@link DocumentBeanV001 .Files }
     * 
     */
    public DocumentBeanV001 .Files createDocumentBeanV001Files() {
        return new DocumentBeanV001 .Files();
    }

    /**
     * Create an instance of {@link DocumentBeanV001 .Locales }
     * 
     */
    public DocumentBeanV001 .Locales createDocumentBeanV001Locales() {
        return new DocumentBeanV001 .Locales();
    }

    /**
     * Create an instance of {@link DocumentBeanV001 .ProductReferences }
     * 
     */
    public DocumentBeanV001 .ProductReferences createDocumentBeanV001ProductReferences() {
        return new DocumentBeanV001 .ProductReferences();
    }

    /**
     * Create an instance of {@link DocumentBeanV001 .Programs }
     * 
     */
    public DocumentBeanV001 .Programs createDocumentBeanV001Programs() {
        return new DocumentBeanV001 .Programs();
    }

    /**
     * Create an instance of {@link DocumentBeanV001 .Ranges }
     * 
     */
    public DocumentBeanV001 .Ranges createDocumentBeanV001Ranges() {
        return new DocumentBeanV001 .Ranges();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AttListType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://document.service.oreo.schneider.com/", name = "attListType")
    public JAXBElement<AttListType> createAttListType(AttListType value) {
        return new JAXBElement<AttListType>(_AttListType_QNAME, AttListType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AttType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://document.service.oreo.schneider.com/", name = "attType")
    public JAXBElement<AttType> createAttType(AttType value) {
        return new JAXBElement<AttType>(_AttType_QNAME, AttType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DocAccessBean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://document.service.oreo.schneider.com/", name = "docAccess")
    public JAXBElement<DocAccessBean> createDocAccess(DocAccessBean value) {
        return new JAXBElement<DocAccessBean>(_DocAccess_QNAME, DocAccessBean.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DocumentBeanV001 }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://document.service.oreo.schneider.com/", name = "documentBeanV001")
    public JAXBElement<DocumentBeanV001> createDocumentBeanV001(DocumentBeanV001 value) {
        return new JAXBElement<DocumentBeanV001>(_DocumentBeanV001_QNAME, DocumentBeanV001 .class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DocumentBeanV002 }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://document.service.oreo.schneider.com/", name = "documentBeanV002")
    public JAXBElement<DocumentBeanV002> createDocumentBeanV002(DocumentBeanV002 value) {
        return new JAXBElement<DocumentBeanV002>(_DocumentBeanV002_QNAME, DocumentBeanV002 .class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DocumentCountBean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://document.service.oreo.schneider.com/", name = "documentCountBean")
    public JAXBElement<DocumentCountBean> createDocumentCountBean(DocumentCountBean value) {
        return new JAXBElement<DocumentCountBean>(_DocumentCountBean_QNAME, DocumentCountBean.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DocumentCountByRangeBean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://document.service.oreo.schneider.com/", name = "documentCountByRangeBean")
    public JAXBElement<DocumentCountByRangeBean> createDocumentCountByRangeBean(DocumentCountByRangeBean value) {
        return new JAXBElement<DocumentCountByRangeBean>(_DocumentCountByRangeBean_QNAME, DocumentCountByRangeBean.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DocumentPageCountBean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://document.service.oreo.schneider.com/", name = "documentPageCountBean")
    public JAXBElement<DocumentPageCountBean> createDocumentPageCountBean(DocumentPageCountBean value) {
        return new JAXBElement<DocumentPageCountBean>(_DocumentPageCountBean_QNAME, DocumentPageCountBean.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DocumentPageDocumentBean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://document.service.oreo.schneider.com/", name = "documentPageDocumentBean")
    public JAXBElement<DocumentPageDocumentBean> createDocumentPageDocumentBean(DocumentPageDocumentBean value) {
        return new JAXBElement<DocumentPageDocumentBean>(_DocumentPageDocumentBean_QNAME, DocumentPageDocumentBean.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Object }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://document.service.oreo.schneider.com/", name = "file")
    public JAXBElement<Object> createFile(Object value) {
        return new JAXBElement<Object>(_File_QNAME, Object.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetDocDetails }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://document.service.oreo.schneider.com/", name = "getDocDetails")
    public JAXBElement<GetDocDetails> createGetDocDetails(GetDocDetails value) {
        return new JAXBElement<GetDocDetails>(_GetDocDetails_QNAME, GetDocDetails.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetDocDetailsByRef }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://document.service.oreo.schneider.com/", name = "getDocDetailsByRef")
    public JAXBElement<GetDocDetailsByRef> createGetDocDetailsByRef(GetDocDetailsByRef value) {
        return new JAXBElement<GetDocDetailsByRef>(_GetDocDetailsByRef_QNAME, GetDocDetailsByRef.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetDocDetailsByRefResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://document.service.oreo.schneider.com/", name = "getDocDetailsByRefResponse")
    public JAXBElement<GetDocDetailsByRefResponse> createGetDocDetailsByRefResponse(GetDocDetailsByRefResponse value) {
        return new JAXBElement<GetDocDetailsByRefResponse>(_GetDocDetailsByRefResponse_QNAME, GetDocDetailsByRefResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetDocDetailsResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://document.service.oreo.schneider.com/", name = "getDocDetailsResponse")
    public JAXBElement<GetDocDetailsResponse> createGetDocDetailsResponse(GetDocDetailsResponse value) {
        return new JAXBElement<GetDocDetailsResponse>(_GetDocDetailsResponse_QNAME, GetDocDetailsResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetDocumentCount }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://document.service.oreo.schneider.com/", name = "getDocumentCount")
    public JAXBElement<GetDocumentCount> createGetDocumentCount(GetDocumentCount value) {
        return new JAXBElement<GetDocumentCount>(_GetDocumentCount_QNAME, GetDocumentCount.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetDocumentCountByRange }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://document.service.oreo.schneider.com/", name = "getDocumentCountByRange")
    public JAXBElement<GetDocumentCountByRange> createGetDocumentCountByRange(GetDocumentCountByRange value) {
        return new JAXBElement<GetDocumentCountByRange>(_GetDocumentCountByRange_QNAME, GetDocumentCountByRange.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetDocumentCountByRangeResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://document.service.oreo.schneider.com/", name = "getDocumentCountByRangeResponse")
    public JAXBElement<GetDocumentCountByRangeResponse> createGetDocumentCountByRangeResponse(GetDocumentCountByRangeResponse value) {
        return new JAXBElement<GetDocumentCountByRangeResponse>(_GetDocumentCountByRangeResponse_QNAME, GetDocumentCountByRangeResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetDocumentCountResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://document.service.oreo.schneider.com/", name = "getDocumentCountResponse")
    public JAXBElement<GetDocumentCountResponse> createGetDocumentCountResponse(GetDocumentCountResponse value) {
        return new JAXBElement<GetDocumentCountResponse>(_GetDocumentCountResponse_QNAME, GetDocumentCountResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetDocumentList }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://document.service.oreo.schneider.com/", name = "getDocumentList")
    public JAXBElement<GetDocumentList> createGetDocumentList(GetDocumentList value) {
        return new JAXBElement<GetDocumentList>(_GetDocumentList_QNAME, GetDocumentList.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetDocumentListResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://document.service.oreo.schneider.com/", name = "getDocumentListResponse")
    public JAXBElement<GetDocumentListResponse> createGetDocumentListResponse(GetDocumentListResponse value) {
        return new JAXBElement<GetDocumentListResponse>(_GetDocumentListResponse_QNAME, GetDocumentListResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetDocumentPage }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://document.service.oreo.schneider.com/", name = "getDocumentPage")
    public JAXBElement<GetDocumentPage> createGetDocumentPage(GetDocumentPage value) {
        return new JAXBElement<GetDocumentPage>(_GetDocumentPage_QNAME, GetDocumentPage.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetDocumentPageResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://document.service.oreo.schneider.com/", name = "getDocumentPageResponse")
    public JAXBElement<GetDocumentPageResponse> createGetDocumentPageResponse(GetDocumentPageResponse value) {
        return new JAXBElement<GetDocumentPageResponse>(_GetDocumentPageResponse_QNAME, GetDocumentPageResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetScopingLanguages }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://document.service.oreo.schneider.com/", name = "getScopingLanguages")
    public JAXBElement<GetScopingLanguages> createGetScopingLanguages(GetScopingLanguages value) {
        return new JAXBElement<GetScopingLanguages>(_GetScopingLanguages_QNAME, GetScopingLanguages.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetScopingLanguagesResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://document.service.oreo.schneider.com/", name = "getScopingLanguagesResponse")
    public JAXBElement<GetScopingLanguagesResponse> createGetScopingLanguagesResponse(GetScopingLanguagesResponse value) {
        return new JAXBElement<GetScopingLanguagesResponse>(_GetScopingLanguagesResponse_QNAME, GetScopingLanguagesResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Locale }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://document.service.oreo.schneider.com/", name = "locale")
    public JAXBElement<Locale> createLocale(Locale value) {
        return new JAXBElement<Locale>(_Locale_QNAME, Locale.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link LocaleBean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://document.service.oreo.schneider.com/", name = "localeBean")
    public JAXBElement<LocaleBean> createLocaleBean(LocaleBean value) {
        return new JAXBElement<LocaleBean>(_LocaleBean_QNAME, LocaleBean.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ProgramBean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://document.service.oreo.schneider.com/", name = "program")
    public JAXBElement<ProgramBean> createProgram(ProgramBean value) {
        return new JAXBElement<ProgramBean>(_Program_QNAME, ProgramBean.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link QueryBean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://document.service.oreo.schneider.com/", name = "queryBean")
    public JAXBElement<QueryBean> createQueryBean(QueryBean value) {
        return new JAXBElement<QueryBean>(_QueryBean_QNAME, QueryBean.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link QueryItemBean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://document.service.oreo.schneider.com/", name = "queryItem")
    public JAXBElement<QueryItemBean> createQueryItem(QueryItemBean value) {
        return new JAXBElement<QueryItemBean>(_QueryItem_QNAME, QueryItemBean.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RangeBeanV001 }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://document.service.oreo.schneider.com/", name = "rangeBeanV001")
    public JAXBElement<RangeBeanV001> createRangeBeanV001(RangeBeanV001 value) {
        return new JAXBElement<RangeBeanV001>(_RangeBeanV001_QNAME, RangeBeanV001 .class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ScopeBean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://document.service.oreo.schneider.com/", name = "scopeBean")
    public JAXBElement<ScopeBean> createScopeBean(ScopeBean value) {
        return new JAXBElement<ScopeBean>(_ScopeBean_QNAME, ScopeBean.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ScopingLanguageBean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://document.service.oreo.schneider.com/", name = "scopingLanguageBean")
    public JAXBElement<ScopingLanguageBean> createScopingLanguageBean(ScopingLanguageBean value) {
        return new JAXBElement<ScopingLanguageBean>(_ScopingLanguageBean_QNAME, ScopingLanguageBean.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TranslatedBean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://document.service.oreo.schneider.com/", name = "translatedBean")
    public JAXBElement<TranslatedBean> createTranslatedBean(TranslatedBean value) {
        return new JAXBElement<TranslatedBean>(_TranslatedBean_QNAME, TranslatedBean.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DocumentServiceException }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://document.service.oreo.schneider.com/", name = "DocumentServiceException")
    public JAXBElement<DocumentServiceException> createDocumentServiceException(DocumentServiceException value) {
        return new JAXBElement<DocumentServiceException>(_DocumentServiceException_QNAME, DocumentServiceException.class, null, value);
    }

}
