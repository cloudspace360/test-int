
package com.schneider.rest.document.service.requests;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class CountBy {

    @JsonProperty("countBy")
    private String countBy;
    @JsonProperty("countParam")
    private String countParam;
    public String getCountBy() {
        return countBy;
    }

    public void setCountBy(String countBy) {
        this.countBy = countBy;
    }

    public String getCountParam() {
        return countParam;
    }

    public void setCountParam(String countParam) {
        this.countParam = countParam;
    }

}
