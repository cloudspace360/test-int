
package com.schneider.oreo.service.document;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for docOrderFieldBean.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="docOrderFieldBean"&gt;
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *     &lt;enumeration value="doc_documentDate"/&gt;
 *     &lt;enumeration value="doc_reference"/&gt;
 *     &lt;enumeration value="doc_popularity"/&gt;
 *     &lt;enumeration value="docType_name"/&gt;
 *     &lt;enumeration value="doc_title"/&gt;
 *     &lt;enumeration value="docType_displayOrder"/&gt;
 *     &lt;enumeration value="docType_orderMapping"/&gt;
 *   &lt;/restriction&gt;
 * &lt;/simpleType&gt;
 * </pre>
 * 
 */
@XmlType(name = "docOrderFieldBean")
@XmlEnum
public enum DocOrderFieldBean {

    @XmlEnumValue("doc_documentDate")
    DOC_DOCUMENT_DATE("doc_documentDate"),
    @XmlEnumValue("doc_reference")
    DOC_REFERENCE("doc_reference"),
    @XmlEnumValue("doc_popularity")
    DOC_POPULARITY("doc_popularity"),
    @XmlEnumValue("docType_name")
    DOC_TYPE_NAME("docType_name"),
    @XmlEnumValue("doc_title")
    DOC_TITLE("doc_title"),
    @XmlEnumValue("docType_displayOrder")
    DOC_TYPE_DISPLAY_ORDER("docType_displayOrder"),
    @XmlEnumValue("docType_orderMapping")
    DOC_TYPE_ORDER_MAPPING("docType_orderMapping");
    private final String value;

    DocOrderFieldBean(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static DocOrderFieldBean fromValue(String v) {
        for (DocOrderFieldBean c: DocOrderFieldBean.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
