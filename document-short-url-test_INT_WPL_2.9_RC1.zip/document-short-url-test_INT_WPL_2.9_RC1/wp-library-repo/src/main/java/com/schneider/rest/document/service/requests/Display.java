
package com.schneider.rest.document.service.requests;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Display {

    @JsonProperty("displayBean")
    private List<DisplayBean> displayBean = new ArrayList<>();
    public List<DisplayBean> getDisplayBean() {
        return displayBean;
    }

    public void setDisplayBean(List<DisplayBean> displayBean) {
        this.displayBean = displayBean;
    }
}
