
package com.schneider.oreo.service.document;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for queryItemName.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="queryItemName"&gt;
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *     &lt;enumeration value="CAT_0_OID"/&gt;
 *     &lt;enumeration value="CAT_1_OID"/&gt;
 *     &lt;enumeration value="TOPIC_OID"/&gt;
 *     &lt;enumeration value="TOPIC_SUB_OID"/&gt;
 *     &lt;enumeration value="APPLICATION_OID"/&gt;
 *     &lt;enumeration value="APPLICATION_NAME"/&gt;
 *     &lt;enumeration value="SEGMENT_OID"/&gt;
 *     &lt;enumeration value="DOMAIN_OID"/&gt;
 *     &lt;enumeration value="DOC_OID"/&gt;
 *     &lt;enumeration value="DOC_REFERENCE"/&gt;
 *   &lt;/restriction&gt;
 * &lt;/simpleType&gt;
 * </pre>
 * 
 */
@XmlType(name = "queryItemName")
@XmlEnum
public enum QueryItemName {

    CAT_0_OID,
    CAT_1_OID,
    TOPIC_OID,
    TOPIC_SUB_OID,
    APPLICATION_OID,
    APPLICATION_NAME,
    SEGMENT_OID,
    DOMAIN_OID,
    DOC_OID,
    DOC_REFERENCE;

    public String value() {
        return name();
    }

    public static QueryItemName fromValue(String v) {
        return valueOf(v);
    }

}
