
package com.schneider.rest.document.service.responses;

import java.util.ArrayList;
import java.util.List;

import javax.xml.datatype.XMLGregorianCalendar;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.schneider.rest.document.details.service.responses.Locales;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Document {

	@JsonProperty("docOid")
	private Long docOid;
	@JsonProperty("reference")
	private String reference;
	@JsonProperty("attributeLists")
	private AttributeLists attributeLists;
	@JsonProperty("attributes")
	private Attributes attributes;
	@JsonProperty("title")
	private String title;
	@JsonProperty("description")
	private String description;
	@JsonProperty("audience")
	private AudienceBean audience;
	@JsonProperty("channels")
	private Channels channels;
	@JsonProperty("creationDate")
	private XMLGregorianCalendar creationDate;
	@JsonProperty("docTypeGroups")
	private DocTypeGroups docTypeGroups;
	@JsonProperty("documentDate")
	private XMLGregorianCalendar documentDate;
	@JsonProperty("documentType")
	private DocumentTypeBean documentType;
	@JsonProperty("expireDate")
	private XMLGregorianCalendar expireDate;
	@JsonProperty("files")
	private Files files;
	@JsonProperty("flipFlopGenerated")
	private Boolean flipFlopGenerated;
	@JsonProperty("lastModificationDate")
	private XMLGregorianCalendar lastModificationDate;
	@JsonProperty("locales")
	private Locales locales;
	@JsonProperty("numberOfPage")
	private Integer numberOfPage;
	@JsonProperty("productReferences")
	private ProductReferences productReferences;
	@JsonProperty("ranges")
	private Ranges ranges;
	@JsonProperty("version")
	private String version;
	@JsonProperty("keywords")
	private String keywords;
	@JsonProperty("partNumber")
	private String partNumber;
	@JsonProperty("revision")
	private String revision;
	@JsonProperty("docAccesses")
	private List<DocAccess> docAccesses = new ArrayList<>();
	@JsonProperty("programs")
	private List<Program> programs = new ArrayList<>();
	@JsonProperty("publicationDate")
	private String publicationDate;
	@JsonProperty("hasTranslations")
	private Boolean hasTranslations;
	@JsonProperty("bannerUrl")
	private String bannerUrl;
	@JsonProperty("hasPreviousVersion")
	protected Boolean hasPreviousVersion;

	public Long getDocOid() {
		return docOid;
	}

	public void setDocOid(Long docOid) {
		this.docOid = docOid;
	}

	public String getReference() {
		return reference;
	}

	public void setReference(String reference) {
		this.reference = reference;
	}

	public AttributeLists getAttributeLists() {
		return attributeLists;
	}

	public void setAttributeLists(AttributeLists attributeLists) {
		this.attributeLists = attributeLists;
	}

	public Attributes getAttributes() {
		return attributes;
	}

	public void setAttributes(Attributes attributes) {
		this.attributes = attributes;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public AudienceBean getAudience() {
		return audience;
	}

	public void setAudience(AudienceBean audience) {
		this.audience = audience;
	}

	public Channels getChannels() {
		return channels;
	}

	public void setChannels(Channels channels) {
		this.channels = channels;
	}

	public DocTypeGroups getDocTypeGroups() {
		return docTypeGroups;
	}

	public void setDocTypeGroups(DocTypeGroups docTypeGroups) {
		this.docTypeGroups = docTypeGroups;
	}

	public DocumentTypeBean getDocumentType() {
		return documentType;
	}

	public void setDocumentType(DocumentTypeBean documentType) {
		this.documentType = documentType;
	}


	public Files getFiles() {
		return files;
	}

	public void setFiles(Files files) {
		this.files = files;
	}

	public Boolean getFlipFlopGenerated() {
		return flipFlopGenerated;
	}

	public void setFlipFlopGenerated(Boolean flipFlopGenerated) {
		this.flipFlopGenerated = flipFlopGenerated;
	}

	public Locales getLocales() {
		return locales;
	}

	public void setLocales(Locales locales) {
		this.locales = locales;
	}

	public Integer getNumberOfPage() {
		return numberOfPage;
	}

	public void setNumberOfPage(Integer numberOfPage) {
		this.numberOfPage = numberOfPage;
	}

	public ProductReferences getProductReferences() {
		return productReferences;
	}

	public void setProductReferences(ProductReferences productReferences) {
		this.productReferences = productReferences;
	}

	public Ranges getRanges() {
		return ranges;
	}

	public void setRanges(Ranges ranges) {
		this.ranges = ranges;
	}

	public String getVersion() {
		return version;
	}

	public void setVersion(String version) {
		this.version = version;
	}

	public String getKeywords() {
		return keywords;
	}

	public void setKeywords(String keywords) {
		this.keywords = keywords;
	}

	public String getPartNumber() {
		return partNumber;
	}

	public void setPartNumber(String partNumber) {
		this.partNumber = partNumber;
	}

	public String getRevision() {
		return revision;
	}

	public void setRevision(String revision) {
		this.revision = revision;
	}

	public List<DocAccess> getDocAccesses() {
		return docAccesses;
	}

	public void setDocAccesses(List<DocAccess> docAccesses) {
		this.docAccesses = docAccesses;
	}

	public List<Program> getPrograms() {
		return programs;
	}

	public void setPrograms(List<Program> programs) {
		this.programs = programs;
	}

	public String getPublicationDate() {
		return publicationDate;
	}

	public void setPublicationDate(String publicationDate) {
		this.publicationDate = publicationDate;
	}

	public Boolean isHasTranslations() {
		return hasTranslations;
	}

	public void setHasTranslations(Boolean hasTranslations) {
		this.hasTranslations = hasTranslations;
	}

	public String getBannerUrl() {
		return bannerUrl;
	}

	public void setBannerUrl(String bannerUrl) {
		this.bannerUrl = bannerUrl;
	}

	public XMLGregorianCalendar getCreationDate() {
		return creationDate;
	}

	public void setCreationDate(XMLGregorianCalendar creationDate) {
		this.creationDate = creationDate;
	}

	public XMLGregorianCalendar getDocumentDate() {
		return documentDate;
	}

	public void setDocumentDate(XMLGregorianCalendar documentDate) {
		this.documentDate = documentDate;
	}

	public XMLGregorianCalendar getExpireDate() {
		return expireDate;
	}

	public void setExpireDate(XMLGregorianCalendar expireDate) {
		this.expireDate = expireDate;
	}

	public XMLGregorianCalendar getLastModificationDate() {
		return lastModificationDate;
	}

	public void setLastModificationDate(XMLGregorianCalendar lastModificationDate) {
		this.lastModificationDate = lastModificationDate;
	}

	public Boolean isHasPreviousVersion() {
		return hasPreviousVersion;
	}

	public void setHasPreviousVersion(Boolean hasPreviousVersion) {
		this.hasPreviousVersion = hasPreviousVersion;
	}
}
