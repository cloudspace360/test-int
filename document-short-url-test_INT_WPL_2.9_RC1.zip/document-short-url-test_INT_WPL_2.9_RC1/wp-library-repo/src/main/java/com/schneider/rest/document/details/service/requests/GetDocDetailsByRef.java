
package com.schneider.rest.document.details.service.requests;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.schneider.rest.product.service.requests.Locale;
import com.schneider.rest.product.service.requests.Scope;

@JsonIgnoreProperties(ignoreUnknown = true)
public class GetDocDetailsByRef {

	@JsonProperty("scope")
	private Scope scope;
	@JsonProperty("locale")
	private Locale locale;
	@JsonProperty("docReference")
	private String docReference;
	@JsonProperty("scopeIndependant")
	private Boolean scopeIndependant;
	@JsonProperty("version")
	private Integer version;

	public Scope getScope() {
		return scope;
	}

	public void setScope(Scope scope) {
		this.scope = scope;
	}

	public Locale getLocale() {
		return locale;
	}

	public void setLocale(Locale locale) {
		this.locale = locale;
	}

	public String getDocReference() {
		return docReference;
	}

	public void setDocReference(String docReference) {
		this.docReference = docReference;
	}

	public Boolean getScopeIndependant() {
		return scopeIndependant;
	}

	public void setScopeIndependant(Boolean scopeIndependant) {
		this.scopeIndependant = scopeIndependant;
	}

	public Integer getVersion() {
		return version;
	}

	public void setVersion(Integer version) {
		this.version = version;
	}
}
