
package com.schneider.rest.document.service.responses;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Range {

    @JsonProperty("id")
    private String id;
    @JsonProperty("oid")
    private Long oid;
    @JsonProperty("status")
    private String status;
    @JsonProperty("name")
    private Name__1 name;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Long getOid() {
        return oid;
    }

    public void setOid(Long oid) {
        this.oid = oid;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Name__1 getName() {
        return name;
    }

    public void setName(Name__1 name) {
        this.name = name;
    }
}
