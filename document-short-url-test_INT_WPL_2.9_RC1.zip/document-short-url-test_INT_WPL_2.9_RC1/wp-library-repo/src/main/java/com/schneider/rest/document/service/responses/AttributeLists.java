
package com.schneider.rest.document.service.responses;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class AttributeLists {

    @JsonProperty("attributeList")
    private List<AttributeList> attributeList = new ArrayList<>();

    public List<AttributeList> getAttributeList() {
        return attributeList;
    }

    public void setAttributeList(List<AttributeList> attributeList) {
        this.attributeList = attributeList;
    }
}
