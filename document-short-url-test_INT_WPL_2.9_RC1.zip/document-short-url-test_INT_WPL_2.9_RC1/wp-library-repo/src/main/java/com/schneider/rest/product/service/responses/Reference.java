
package com.schneider.rest.product.service.responses;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Reference {

    @JsonProperty("docType")
    private String docType;
    @JsonProperty("docTypeOid")
    private Long docTypeOid;
    @JsonProperty("scoped")
    private Boolean scoped;
    @JsonProperty("main")
    private Boolean main;
    @JsonProperty("reference")
    private String reference;

    public String getDocType() {
        return docType;
    }

    public void setDocType(String docType) {
        this.docType = docType;
    }

    public Long getDocTypeOid() {
        return docTypeOid;
    }

    public void setDocTypeOid(Long docTypeOid) {
        this.docTypeOid = docTypeOid;
    }

    public Boolean getScoped() {
        return scoped;
    }

    public void setScoped(Boolean scoped) {
        this.scoped = scoped;
    }

    public Boolean getMain() {
        return main;
    }

    public void setMain(Boolean main) {
        this.main = main;
    }

    public String getReference() {
        return reference;
    }

    public void setReference(String reference) {
        this.reference = reference;
    }
}
