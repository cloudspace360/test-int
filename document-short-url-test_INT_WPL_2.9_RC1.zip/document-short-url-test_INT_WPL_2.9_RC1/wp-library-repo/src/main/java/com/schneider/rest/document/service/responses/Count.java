
package com.schneider.rest.document.service.responses;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Count {

    @JsonProperty("numberOfDocs")
    private Long numberOfDocs;
    @JsonProperty("id")
    private String id;
    @JsonProperty("oid")
    private Long oid;
    @JsonProperty("status")
    private String status;
    @JsonProperty("rangeType")
    private String rangeType;
    @JsonProperty("name")
    private Name name;
    @JsonProperty("baseName")
    private BaseName baseName;

    public Long getNumberOfDocs() {
        return numberOfDocs;
    }

    public void setNumberOfDocs(Long numberOfDocs) {
        this.numberOfDocs = numberOfDocs;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Long getOid() {
        return oid;
    }

    public void setOid(Long oid) {
        this.oid = oid;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getRangeType() {
        return rangeType;
    }

    public void setRangeType(String rangeType) {
        this.rangeType = rangeType;
    }

    public Name getName() {
        return name;
    }

    public void setName(Name name) {
        this.name = name;
    }

    public BaseName getBaseName() {
        return baseName;
    }

    public void setBaseName(BaseName baseName) {
        this.baseName = baseName;
    }
}
