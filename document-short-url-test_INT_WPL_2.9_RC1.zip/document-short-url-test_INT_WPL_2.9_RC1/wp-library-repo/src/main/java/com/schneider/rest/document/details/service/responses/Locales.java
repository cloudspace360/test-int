
package com.schneider.rest.document.details.service.responses;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Locales {
	@JsonProperty("locale")
	private List<Locale> locale = new ArrayList<>();

	public List<Locale> getLocale() {
		return locale;
	}

	public void setLocale(List<Locale> locale) {
		this.locale = locale;
	}

}
