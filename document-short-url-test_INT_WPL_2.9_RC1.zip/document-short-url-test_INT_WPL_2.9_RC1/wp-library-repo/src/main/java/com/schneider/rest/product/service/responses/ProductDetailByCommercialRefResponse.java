
package com.schneider.rest.product.service.responses;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class ProductDetailByCommercialRefResponse {

    @JsonProperty("getProductDetailByCommercialRefResponse")
    private GetProductDetailByCommercialRefResponse getProductDetailByCommercialRefResponse;

    public GetProductDetailByCommercialRefResponse getGetProductDetailByCommercialRefResponse() {
        return getProductDetailByCommercialRefResponse;
    }

    public void setGetProductDetailByCommercialRefResponse(GetProductDetailByCommercialRefResponse getProductDetailByCommercialRefResponse) {
        this.getProductDetailByCommercialRefResponse = getProductDetailByCommercialRefResponse;
    }
}
