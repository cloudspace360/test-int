
package com.schneider.rest.document.service.requests;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Order {

    @JsonProperty("orderBean")
    private List<OrderBean> orderBean = new ArrayList<>();

    public List<OrderBean> getOrderBean() {
        return orderBean;
    }

    public void setOrderBean(List<OrderBean> orderBean) {
        this.orderBean = orderBean;
    }

    public Order withOrderBean(List<OrderBean> orderBean) {
        this.orderBean = orderBean;
        return this;
    }
}
