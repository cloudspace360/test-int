
package com.schneider.oreo.service.document;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for documentCountByRangeBean complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="documentCountByRangeBean"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://document.service.oreo.schneider.com/}documentCountBean"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="rangeId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="status" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "documentCountByRangeBean", propOrder = {
    "rangeId",
    "status"
})
public class DocumentCountByRangeBean
    extends DocumentCountBean
{

    protected String rangeId;
    protected String status;

    /**
     * Gets the value of the rangeId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRangeId() {
        return rangeId;
    }

    /**
     * Sets the value of the rangeId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRangeId(String value) {
        this.rangeId = value;
    }

    /**
     * Gets the value of the status property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStatus() {
        return status;
    }

    /**
     * Sets the value of the status property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStatus(String value) {
        this.status = value;
    }

}
