
package com.schneider.oreo.service.document;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for docOrderBean complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="docOrderBean"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://document.service.oreo.schneider.com/}orderBean"&gt;
 *       &lt;sequence&gt;
 *       &lt;/sequence&gt;
 *       &lt;attribute name="field" use="required" type="{http://document.service.oreo.schneider.com/}docOrderFieldBean" /&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "docOrderBean")
public class DocOrderBean
    extends OrderBean
{

    @XmlAttribute(name = "field", required = true)
    protected DocOrderFieldBean field;

    /**
     * Gets the value of the field property.
     * 
     * @return
     *     possible object is
     *     {@link DocOrderFieldBean }
     *     
     */
    public DocOrderFieldBean getField() {
        return field;
    }

    /**
     * Sets the value of the field property.
     * 
     * @param value
     *     allowed object is
     *     {@link DocOrderFieldBean }
     *     
     */
    public void setField(DocOrderFieldBean value) {
        this.field = value;
    }

}
