
package com.schneider.oreo.service.document;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for getDocumentCount complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="getDocumentCount"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="applicationToken" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="scope" type="{http://document.service.oreo.schneider.com/}scopeBean"/&gt;
 *         &lt;element name="locale" type="{http://document.service.oreo.schneider.com/}localeBean"/&gt;
 *         &lt;element name="query" type="{http://document.service.oreo.schneider.com/}queryBean" minOccurs="0"/&gt;
 *         &lt;element name="search" type="{http://document.service.oreo.schneider.com/}searchBeans" minOccurs="0"/&gt;
 *         &lt;element name="countBy" type="{http://document.service.oreo.schneider.com/}docCountByBean"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "getDocumentCount", propOrder = {
    "applicationToken",
    "scope",
    "locale",
    "query",
    "search",
    "countBy"
})
public class GetDocumentCount {

    protected String applicationToken;
    @XmlElement(required = true)
    protected ScopeBean scope;
    @XmlElement(required = true)
    protected LocaleBean locale;
    protected QueryBean query;
    protected SearchBeans search;
    @XmlElement(required = true)
    protected DocCountByBean countBy;

    /**
     * Gets the value of the applicationToken property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getApplicationToken() {
        return applicationToken;
    }

    /**
     * Sets the value of the applicationToken property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setApplicationToken(String value) {
        this.applicationToken = value;
    }

    /**
     * Gets the value of the scope property.
     * 
     * @return
     *     possible object is
     *     {@link ScopeBean }
     *     
     */
    public ScopeBean getScope() {
        return scope;
    }

    /**
     * Sets the value of the scope property.
     * 
     * @param value
     *     allowed object is
     *     {@link ScopeBean }
     *     
     */
    public void setScope(ScopeBean value) {
        this.scope = value;
    }

    /**
     * Gets the value of the locale property.
     * 
     * @return
     *     possible object is
     *     {@link LocaleBean }
     *     
     */
    public LocaleBean getLocale() {
        return locale;
    }

    /**
     * Sets the value of the locale property.
     * 
     * @param value
     *     allowed object is
     *     {@link LocaleBean }
     *     
     */
    public void setLocale(LocaleBean value) {
        this.locale = value;
    }

    /**
     * Gets the value of the query property.
     * 
     * @return
     *     possible object is
     *     {@link QueryBean }
     *     
     */
    public QueryBean getQuery() {
        return query;
    }

    /**
     * Sets the value of the query property.
     * 
     * @param value
     *     allowed object is
     *     {@link QueryBean }
     *     
     */
    public void setQuery(QueryBean value) {
        this.query = value;
    }

    /**
     * Gets the value of the search property.
     * 
     * @return
     *     possible object is
     *     {@link SearchBeans }
     *     
     */
    public SearchBeans getSearch() {
        return search;
    }

    /**
     * Sets the value of the search property.
     * 
     * @param value
     *     allowed object is
     *     {@link SearchBeans }
     *     
     */
    public void setSearch(SearchBeans value) {
        this.search = value;
    }

    /**
     * Gets the value of the countBy property.
     * 
     * @return
     *     possible object is
     *     {@link DocCountByBean }
     *     
     */
    public DocCountByBean getCountBy() {
        return countBy;
    }

    /**
     * Sets the value of the countBy property.
     * 
     * @param value
     *     allowed object is
     *     {@link DocCountByBean }
     *     
     */
    public void setCountBy(DocCountByBean value) {
        this.countBy = value;
    }

}
