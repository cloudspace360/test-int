
package com.schneider.oreo.service.document;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for docDisplayBean complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="docDisplayBean"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *       &lt;/sequence&gt;
 *       &lt;attribute name="field" use="required" type="{http://document.service.oreo.schneider.com/}docDisplayFieldBean" /&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "docDisplayBean")
public class DocDisplayBean {

    @XmlAttribute(name = "field", required = true)
    protected DocDisplayFieldBean field;

    /**
     * Gets the value of the field property.
     * 
     * @return
     *     possible object is
     *     {@link DocDisplayFieldBean }
     *     
     */
    public DocDisplayFieldBean getField() {
        return field;
    }

    /**
     * Sets the value of the field property.
     * 
     * @param value
     *     allowed object is
     *     {@link DocDisplayFieldBean }
     *     
     */
    public void setField(DocDisplayFieldBean value) {
        this.field = value;
    }

}
