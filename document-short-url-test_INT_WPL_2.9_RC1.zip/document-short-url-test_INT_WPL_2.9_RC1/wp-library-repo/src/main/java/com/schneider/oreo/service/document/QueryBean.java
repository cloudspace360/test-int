
package com.schneider.oreo.service.document;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for queryBean complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="queryBean"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="attListType" type="{http://document.service.oreo.schneider.com/}attListType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="attListValues" type="{http://www.w3.org/2001/XMLSchema}long" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="attType" type="{http://document.service.oreo.schneider.com/}attType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="attValues" type="{http://www.w3.org/2001/XMLSchema}long" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="audiences" type="{http://www.w3.org/2001/XMLSchema}long" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="availableForCountryId" type="{http://www.w3.org/2001/XMLSchema}long" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="availableForCountryName" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="brands" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="categories" type="{http://www.w3.org/2001/XMLSchema}long" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="docAccesses" minOccurs="0"&gt;
 *           &lt;complexType&gt;
 *             &lt;complexContent&gt;
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                 &lt;sequence&gt;
 *                   &lt;element name="docAccess" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0"/&gt;
 *                 &lt;/sequence&gt;
 *               &lt;/restriction&gt;
 *             &lt;/complexContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="docTypeGroups" type="{http://www.w3.org/2001/XMLSchema}long" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="docTypes" type="{http://www.w3.org/2001/XMLSchema}long" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="fileExtensions" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="locales" type="{http://www.w3.org/2001/XMLSchema}long" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="nodeIds" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="product" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="productCommRef" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="queryBean" type="{http://document.service.oreo.schneider.com/}queryItemBean" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="rangeIds" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="rangeStatus" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="ranges" type="{http://www.w3.org/2001/XMLSchema}long" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="searchAttributeFilter" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="searchString" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="tags" type="{http://www.w3.org/2001/XMLSchema}long" maxOccurs="unbounded" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "queryBean", propOrder = {
    "attListType",
    "attListValues",
    "attType",
    "attValues",
    "audiences",
    "availableForCountryId",
    "availableForCountryName",
    "brands",
    "categories",
    "docAccesses",
    "docTypeGroups",
    "docTypes",
    "fileExtensions",
    "locales",
    "nodeIds",
    "product",
    "productCommRef",
    "queryBean",
    "rangeIds",
    "rangeStatus",
    "ranges",
    "searchAttributeFilter",
    "searchString",
    "tags"
})
public class QueryBean {

    @XmlElement(nillable = true)
    protected List<AttListType> attListType;
    @XmlElement(nillable = true)
    protected List<Long> attListValues;
    @XmlElement(nillable = true)
    protected List<AttType> attType;
    @XmlElement(nillable = true)
    protected List<Long> attValues;
    @XmlElement(nillable = true)
    protected List<Long> audiences;
    @XmlElement(nillable = true)
    protected List<Long> availableForCountryId;
    @XmlElement(nillable = true)
    protected List<String> availableForCountryName;
    @XmlElement(nillable = true)
    protected List<String> brands;
    @XmlElement(nillable = true)
    protected List<Long> categories;
    protected QueryBean.DocAccesses docAccesses;
    @XmlElement(nillable = true)
    protected List<Long> docTypeGroups;
    @XmlElement(nillable = true)
    protected List<Long> docTypes;
    @XmlElement(nillable = true)
    protected List<String> fileExtensions;
    @XmlElement(nillable = true)
    protected List<Long> locales;
    @XmlElement(nillable = true)
    protected List<String> nodeIds;
    protected String product;
    protected String productCommRef;
    protected List<QueryItemBean> queryBean;
    @XmlElement(nillable = true)
    protected List<String> rangeIds;
    protected String rangeStatus;
    @XmlElement(nillable = true)
    protected List<Long> ranges;
    protected String searchAttributeFilter;
    protected String searchString;
    @XmlElement(nillable = true)
    protected List<Long> tags;

    /**
     * Gets the value of the attListType property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the attListType property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAttListType().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link AttListType }
     * 
     * 
     */
    public List<AttListType> getAttListType() {
        if (attListType == null) {
            attListType = new ArrayList<AttListType>();
        }
        return this.attListType;
    }

    /**
     * Gets the value of the attListValues property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the attListValues property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAttListValues().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Long }
     * 
     * 
     */
    public List<Long> getAttListValues() {
        if (attListValues == null) {
            attListValues = new ArrayList<Long>();
        }
        return this.attListValues;
    }

    /**
     * Gets the value of the attType property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the attType property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAttType().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link AttType }
     * 
     * 
     */
    public List<AttType> getAttType() {
        if (attType == null) {
            attType = new ArrayList<AttType>();
        }
        return this.attType;
    }

    /**
     * Gets the value of the attValues property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the attValues property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAttValues().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Long }
     * 
     * 
     */
    public List<Long> getAttValues() {
        if (attValues == null) {
            attValues = new ArrayList<Long>();
        }
        return this.attValues;
    }

    /**
     * Gets the value of the audiences property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the audiences property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAudiences().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Long }
     * 
     * 
     */
    public List<Long> getAudiences() {
        if (audiences == null) {
            audiences = new ArrayList<Long>();
        }
        return this.audiences;
    }

    /**
     * Gets the value of the availableForCountryId property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the availableForCountryId property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAvailableForCountryId().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Long }
     * 
     * 
     */
    public List<Long> getAvailableForCountryId() {
        if (availableForCountryId == null) {
            availableForCountryId = new ArrayList<Long>();
        }
        return this.availableForCountryId;
    }

    /**
     * Gets the value of the availableForCountryName property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the availableForCountryName property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAvailableForCountryName().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link String }
     * 
     * 
     */
    public List<String> getAvailableForCountryName() {
        if (availableForCountryName == null) {
            availableForCountryName = new ArrayList<String>();
        }
        return this.availableForCountryName;
    }

    /**
     * Gets the value of the brands property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the brands property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getBrands().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link String }
     * 
     * 
     */
    public List<String> getBrands() {
        if (brands == null) {
            brands = new ArrayList<String>();
        }
        return this.brands;
    }

    /**
     * Gets the value of the categories property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the categories property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getCategories().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Long }
     * 
     * 
     */
    public List<Long> getCategories() {
        if (categories == null) {
            categories = new ArrayList<Long>();
        }
        return this.categories;
    }

    /**
     * Gets the value of the docAccesses property.
     * 
     * @return
     *     possible object is
     *     {@link QueryBean.DocAccesses }
     *     
     */
    public QueryBean.DocAccesses getDocAccesses() {
        return docAccesses;
    }

    /**
     * Sets the value of the docAccesses property.
     * 
     * @param value
     *     allowed object is
     *     {@link QueryBean.DocAccesses }
     *     
     */
    public void setDocAccesses(QueryBean.DocAccesses value) {
        this.docAccesses = value;
    }

    /**
     * Gets the value of the docTypeGroups property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the docTypeGroups property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getDocTypeGroups().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Long }
     * 
     * 
     */
    public List<Long> getDocTypeGroups() {
        if (docTypeGroups == null) {
            docTypeGroups = new ArrayList<Long>();
        }
        return this.docTypeGroups;
    }

    /**
     * Gets the value of the docTypes property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the docTypes property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getDocTypes().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Long }
     * 
     * 
     */
    public List<Long> getDocTypes() {
        if (docTypes == null) {
            docTypes = new ArrayList<Long>();
        }
        return this.docTypes;
    }

    /**
     * Gets the value of the fileExtensions property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the fileExtensions property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getFileExtensions().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link String }
     * 
     * 
     */
    public List<String> getFileExtensions() {
        if (fileExtensions == null) {
            fileExtensions = new ArrayList<String>();
        }
        return this.fileExtensions;
    }

    /**
     * Gets the value of the locales property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the locales property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getLocales().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Long }
     * 
     * 
     */
    public List<Long> getLocales() {
        if (locales == null) {
            locales = new ArrayList<Long>();
        }
        return this.locales;
    }

    /**
     * Gets the value of the nodeIds property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the nodeIds property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getNodeIds().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link String }
     * 
     * 
     */
    public List<String> getNodeIds() {
        if (nodeIds == null) {
            nodeIds = new ArrayList<String>();
        }
        return this.nodeIds;
    }

    /**
     * Gets the value of the product property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProduct() {
        return product;
    }

    /**
     * Sets the value of the product property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProduct(String value) {
        this.product = value;
    }

    /**
     * Gets the value of the productCommRef property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProductCommRef() {
        return productCommRef;
    }

    /**
     * Sets the value of the productCommRef property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProductCommRef(String value) {
        this.productCommRef = value;
    }

    /**
     * Gets the value of the queryBean property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the queryBean property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getQueryBean().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link QueryItemBean }
     * 
     * 
     */
    public List<QueryItemBean> getQueryBean() {
        if (queryBean == null) {
            queryBean = new ArrayList<QueryItemBean>();
        }
        return this.queryBean;
    }

    /**
     * Gets the value of the rangeIds property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the rangeIds property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getRangeIds().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link String }
     * 
     * 
     */
    public List<String> getRangeIds() {
        if (rangeIds == null) {
            rangeIds = new ArrayList<String>();
        }
        return this.rangeIds;
    }

    /**
     * Gets the value of the rangeStatus property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRangeStatus() {
        return rangeStatus;
    }

    /**
     * Sets the value of the rangeStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRangeStatus(String value) {
        this.rangeStatus = value;
    }

    /**
     * Gets the value of the ranges property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the ranges property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getRanges().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Long }
     * 
     * 
     */
    public List<Long> getRanges() {
        if (ranges == null) {
            ranges = new ArrayList<Long>();
        }
        return this.ranges;
    }

    /**
     * Gets the value of the searchAttributeFilter property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSearchAttributeFilter() {
        return searchAttributeFilter;
    }

    /**
     * Sets the value of the searchAttributeFilter property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSearchAttributeFilter(String value) {
        this.searchAttributeFilter = value;
    }

    /**
     * Gets the value of the searchString property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSearchString() {
        return searchString;
    }

    /**
     * Sets the value of the searchString property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSearchString(String value) {
        this.searchString = value;
    }

    /**
     * Gets the value of the tags property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the tags property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getTags().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Long }
     * 
     * 
     */
    public List<Long> getTags() {
        if (tags == null) {
            tags = new ArrayList<Long>();
        }
        return this.tags;
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;complexContent&gt;
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *       &lt;sequence&gt;
     *         &lt;element name="docAccess" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0"/&gt;
     *       &lt;/sequence&gt;
     *     &lt;/restriction&gt;
     *   &lt;/complexContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "docAccess"
    })
    public static class DocAccesses {

        @XmlElement(nillable = true)
        protected List<String> docAccess;

        /**
         * Gets the value of the docAccess property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the docAccess property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getDocAccess().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link String }
         * 
         * 
         */
        public List<String> getDocAccess() {
            if (docAccess == null) {
                docAccess = new ArrayList<String>();
            }
            return this.docAccess;
        }

    }

}
