
package com.schneider.rest.document.service.responses;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class DocTypeGroups {

    @JsonProperty("docTypeGroup")
    private List<DocTypeGroup> docTypeGroup = new ArrayList<>();

    public List<DocTypeGroup> getDocTypeGroup() {
        return docTypeGroup;
    }

    public void setDocTypeGroup(List<DocTypeGroup> docTypeGroup) {
        this.docTypeGroup = docTypeGroup;
    }
}
