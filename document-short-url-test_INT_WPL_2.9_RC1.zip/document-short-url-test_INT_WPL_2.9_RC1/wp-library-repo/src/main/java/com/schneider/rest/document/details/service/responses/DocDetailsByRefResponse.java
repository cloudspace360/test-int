
package com.schneider.rest.document.details.service.responses;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class DocDetailsByRefResponse {

    @JsonProperty("getDocDetailsByRefResponse")
    private GetDocDetailsByRefResponse getDocDetailsByRefResponse;

    public GetDocDetailsByRefResponse getGetDocDetailsByRefResponse() {
        return getDocDetailsByRefResponse;
    }

    public void setGetDocDetailsByRefResponse(GetDocDetailsByRefResponse getDocDetailsByRefResponse) {
        this.getDocDetailsByRefResponse = getDocDetailsByRefResponse;
    }
}
