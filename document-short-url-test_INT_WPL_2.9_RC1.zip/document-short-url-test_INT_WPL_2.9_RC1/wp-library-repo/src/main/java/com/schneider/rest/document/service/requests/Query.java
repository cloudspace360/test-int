
package com.schneider.rest.document.service.requests;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.schneider.rest.document.details.service.responses.AttType;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Query {
	@JsonInclude(Include.NON_EMPTY)
	@JsonProperty("attType")
	private List<AttType> attType = new ArrayList<>();
	public List<AttType> getAttType() {
		return attType;
	}

	public void setAttType(List<AttType> attType) {
		this.attType = attType;
	}

	@JsonInclude(Include.NON_EMPTY)
	@JsonProperty("rangeIds")
	private List<Long> rangeIds = new ArrayList<>();
	@JsonInclude(Include.NON_EMPTY)
	@JsonProperty("channels")
	private List<String> channels = new ArrayList<>();
	@JsonProperty("queryBean")
	private List<QueryBean> queryBean = new ArrayList<>();
	@JsonInclude(Include.NON_EMPTY)
	@JsonProperty("docTypeGroups")
	private List<Long> docTypeGroups = new ArrayList<>();
	@JsonInclude(Include.NON_EMPTY)
	@JsonProperty("docTypes")
	private List<Long> docTypes = new ArrayList<>();
	@JsonInclude(Include.NON_EMPTY)
	@JsonProperty("locales")
	private List<Long> locales = new ArrayList<>();
	@JsonInclude(Include.NON_NULL)
	private String searchAttributeFilter;
	@JsonInclude(Include.NON_NULL)
	@JsonProperty("locales")
	protected String searchString;
	@JsonInclude(Include.NON_EMPTY)
	@JsonProperty("attListValues")
	private List<Long> attListValues = new ArrayList<>();

	public List<Long> getRangeIds() {
		return rangeIds;
	}

	public void setRangeIds(List<Long> rangeIds) {
		this.rangeIds = rangeIds;
	}

	public List<String> getChannels() {
		return channels;
	}

	public void setChannels(List<String> channels) {
		this.channels = channels;
	}

	public List<QueryBean> getQueryBean() {
		return queryBean;
	}

	public void setQueryBean(List<QueryBean> queryBean) {
		this.queryBean = queryBean;
	}

	public List<Long> getDocTypeGroups() {
		return docTypeGroups;
	}

	public void setDocTypeGroups(List<Long> docTypeGroups) {
		this.docTypeGroups = docTypeGroups;
	}

	public List<Long> getDocTypes() {
		return docTypes;
	}

	public void setDocTypes(List<Long> docTypes) {
		this.docTypes = docTypes;
	}

	/*
	 * public List<Long> getLocales() { return locales; }
	 * 
	 * public void setLocales(List<Long> locales) { this.locales = locales; }
	 */
	public String getSearchAttributeFilter() {
		return searchAttributeFilter;
	}

	public void setSearchAttributeFilter(String searchAttributeFilter) {
		this.searchAttributeFilter = searchAttributeFilter;
	}

	public String getSearchString() {
		return searchString;
	}

	public void setSearchString(String searchString) {
		this.searchString = searchString;
	}

	public List<Long> getAttListValues() {
		return attListValues;
	}

	public void setAttListValues(List<Long> attListValues) {
		this.attListValues = attListValues;
	}

}
