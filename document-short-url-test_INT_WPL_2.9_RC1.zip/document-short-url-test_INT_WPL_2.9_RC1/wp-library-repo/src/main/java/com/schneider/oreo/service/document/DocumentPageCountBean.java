
package com.schneider.oreo.service.document;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for documentPageCountBean complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="documentPageCountBean"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="name" type="{http://document.service.oreo.schneider.com/}translatedBean" minOccurs="0"/&gt;
 *         &lt;element name="baseName" type="{http://document.service.oreo.schneider.com/}translatedBean" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *       &lt;attribute name="id" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="numberOfDocs" type="{http://www.w3.org/2001/XMLSchema}long" /&gt;
 *       &lt;attribute name="oid" type="{http://www.w3.org/2001/XMLSchema}long" /&gt;
 *       &lt;attribute name="status" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "documentPageCountBean", propOrder = {
    "name",
    "baseName"
})
public class DocumentPageCountBean {

    protected TranslatedBean name;
    protected TranslatedBean baseName;
    @XmlAttribute(name = "id")
    protected String id;
    @XmlAttribute(name = "numberOfDocs")
    protected Long numberOfDocs;
    @XmlAttribute(name = "oid")
    protected Long oid;
    @XmlAttribute(name = "status")
    protected String status;

    /**
     * Gets the value of the name property.
     * 
     * @return
     *     possible object is
     *     {@link TranslatedBean }
     *     
     */
    public TranslatedBean getName() {
        return name;
    }

    /**
     * Sets the value of the name property.
     * 
     * @param value
     *     allowed object is
     *     {@link TranslatedBean }
     *     
     */
    public void setName(TranslatedBean value) {
        this.name = value;
    }

    /**
     * Gets the value of the baseName property.
     * 
     * @return
     *     possible object is
     *     {@link TranslatedBean }
     *     
     */
    public TranslatedBean getBaseName() {
        return baseName;
    }

    /**
     * Sets the value of the baseName property.
     * 
     * @param value
     *     allowed object is
     *     {@link TranslatedBean }
     *     
     */
    public void setBaseName(TranslatedBean value) {
        this.baseName = value;
    }

    /**
     * Gets the value of the id property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getId() {
        return id;
    }

    /**
     * Sets the value of the id property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setId(String value) {
        this.id = value;
    }

    /**
     * Gets the value of the numberOfDocs property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getNumberOfDocs() {
        return numberOfDocs;
    }

    /**
     * Sets the value of the numberOfDocs property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setNumberOfDocs(Long value) {
        this.numberOfDocs = value;
    }

    /**
     * Gets the value of the oid property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getOid() {
        return oid;
    }

    /**
     * Sets the value of the oid property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setOid(Long value) {
        this.oid = value;
    }

    /**
     * Gets the value of the status property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStatus() {
        return status;
    }

    /**
     * Sets the value of the status property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStatus(String value) {
        this.status = value;
    }

}
