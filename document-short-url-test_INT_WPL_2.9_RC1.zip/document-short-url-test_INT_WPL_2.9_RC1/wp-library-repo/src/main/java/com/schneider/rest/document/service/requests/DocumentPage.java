
package com.schneider.rest.document.service.requests;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class DocumentPage {

    @JsonProperty("getDocumentPage")
    private GetDocumentPage getDocumentPage;

    public GetDocumentPage getGetDocumentPage() {
        return getDocumentPage;
    }

    public void setGetDocumentPage(GetDocumentPage getDocumentPage) {
        this.getDocumentPage = getDocumentPage;
    }

}
