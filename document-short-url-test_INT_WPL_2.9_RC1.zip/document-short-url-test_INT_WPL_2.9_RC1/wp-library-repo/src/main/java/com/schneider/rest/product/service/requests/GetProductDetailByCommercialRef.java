
package com.schneider.rest.product.service.requests;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class GetProductDetailByCommercialRef {
	@JsonProperty("scope")
	private Scope scope;
	@JsonProperty("locale")
	private Locale locale;
	@JsonProperty("commercialRef")
	private String commercialRef;
	@JsonProperty("semanticCharacteristics")
	private String semanticCharacteristics;
	@JsonProperty("version")
	private String version;
	@JsonProperty("scopeIndependant")
	private String scopeIndependant;

	public Scope getScope() {
		return scope;
	}

	public void setScope(Scope scope) {
		this.scope = scope;
	}

	public Locale getLocale() {
		return locale;
	}

	public void setLocale(Locale locale) {
		this.locale = locale;
	}

	public String getCommercialRef() {
		return commercialRef;
	}

	public void setCommercialRef(String commercialRef) {
		this.commercialRef = commercialRef;
	}

	public String getSemanticCharacteristics() {
		return semanticCharacteristics;
	}

	public void setSemanticCharacteristics(String semanticCharacteristics) {
		this.semanticCharacteristics = semanticCharacteristics;
	}

	public String getVersion() {
		return version;
	}

	public void setVersion(String version) {
		this.version = version;
	}

	public String getScopeIndependant() {
		return scopeIndependant;
	}

	public void setScopeIndependant(String scopeIndependant) {
		this.scopeIndependant = scopeIndependant;
	}
}
