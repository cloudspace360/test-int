
package com.schneider.oreo.service.document;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for searchFieldBean.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="searchFieldBean"&gt;
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *     &lt;enumeration value="doc_title"/&gt;
 *     &lt;enumeration value="doc_description"/&gt;
 *     &lt;enumeration value="doc_keywords"/&gt;
 *     &lt;enumeration value="doc_reference"/&gt;
 *     &lt;enumeration value="product_reference"/&gt;
 *     &lt;enumeration value="docType_name"/&gt;
 *     &lt;enumeration value="range_name"/&gt;
 *     &lt;enumeration value="attListType"/&gt;
 *     &lt;enumeration value="attType"/&gt;
 *   &lt;/restriction&gt;
 * &lt;/simpleType&gt;
 * </pre>
 * 
 */
@XmlType(name = "searchFieldBean")
@XmlEnum
public enum SearchFieldBean {

    @XmlEnumValue("doc_title")
    DOC_TITLE("doc_title"),
    @XmlEnumValue("doc_description")
    DOC_DESCRIPTION("doc_description"),
    @XmlEnumValue("doc_keywords")
    DOC_KEYWORDS("doc_keywords"),
    @XmlEnumValue("doc_reference")
    DOC_REFERENCE("doc_reference"),
    @XmlEnumValue("product_reference")
    PRODUCT_REFERENCE("product_reference"),
    @XmlEnumValue("docType_name")
    DOC_TYPE_NAME("docType_name"),
    @XmlEnumValue("range_name")
    RANGE_NAME("range_name"),
    @XmlEnumValue("attListType")
    ATT_LIST_TYPE("attListType"),
    @XmlEnumValue("attType")
    ATT_TYPE("attType");
    private final String value;

    SearchFieldBean(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static SearchFieldBean fromValue(String v) {
        for (SearchFieldBean c: SearchFieldBean.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
