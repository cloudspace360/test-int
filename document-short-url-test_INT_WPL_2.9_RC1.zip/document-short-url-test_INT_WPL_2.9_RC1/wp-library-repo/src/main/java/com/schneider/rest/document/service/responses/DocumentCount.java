
package com.schneider.rest.document.service.responses;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class DocumentCount {

	@JsonProperty("field")
	private String field;
	@JsonProperty("param")
	private String param;
	@JsonProperty("count")
	private List<Count> count = new ArrayList<>();

	public String getField() {
		return field;
	}

	public void setField(String field) {
		this.field = field;
	}

	public List<Count> getCount() {
		return count;
	}

	public void setCount(List<Count> count) {
		this.count = count;
	}

	public String getParam() {
		return param;
	}

	public void setParam(String param) {
		this.param = param;
	}
}
