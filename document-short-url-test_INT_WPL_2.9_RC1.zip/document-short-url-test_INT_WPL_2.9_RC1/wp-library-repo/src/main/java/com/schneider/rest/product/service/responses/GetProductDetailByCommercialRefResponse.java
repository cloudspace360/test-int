
package com.schneider.rest.product.service.responses;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class GetProductDetailByCommercialRefResponse {

    @JsonProperty("ProductBean")
    private ProductBeanRest productBean;

    public ProductBeanRest getProductBean() {
        return productBean;
    }

    public void setProductBean(ProductBeanRest productBean) {
        this.productBean = productBean;
    }
}
