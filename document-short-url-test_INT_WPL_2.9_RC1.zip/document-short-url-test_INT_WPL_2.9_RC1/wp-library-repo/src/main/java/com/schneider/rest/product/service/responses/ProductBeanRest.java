
package com.schneider.rest.product.service.responses;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class ProductBeanRest {

    @JsonProperty("globalStatus")
    private String globalStatus;
    @JsonProperty("oid")
    private Long oid;
    @JsonProperty("productId")
    private String productId;
    @JsonProperty("characteristicCategories")
    private CharacteristicCategories characteristicCategories;
    @JsonProperty("commercialReference")
    private String commercialReference;
    @JsonProperty("commercializedProduct")
    private CommercializedProduct commercializedProduct;
    @JsonProperty("documentOids")
    private DocumentOids documentOids;
    @JsonProperty("eanCode")
    private String eanCode;
    @JsonProperty("epdsDocumentOid")
    private Long epdsDocumentOid;
    @JsonProperty("greenPremium")
    private Boolean greenPremium;
    @JsonProperty("highligthedCharacteristics")
    private HighligthedCharacteristics highligthedCharacteristics;
    @JsonProperty("longDescription")
    private String longDescription;
    @JsonProperty("parentNodeOid")
    private Long parentNodeOid;
    @JsonProperty("parentRangeId")
    private String parentRangeId;
    @JsonProperty("parentRangeOid")
    private Long parentRangeOid;
    @JsonProperty("pictureDocumentOid")
    private Long pictureDocumentOid;
    @JsonProperty("parents")
    private Parents parents;
    @JsonProperty("ranges")
    private Ranges ranges;
    @JsonProperty("shortDescription")
    private String shortDescription;
    @JsonProperty("documentReferences")
    private DocumentReferences documentReferences;
    @JsonProperty("pictureDocumentReference")
    private String pictureDocumentReference;
    @JsonProperty("pictures")
    private Pictures pictures;
    @JsonProperty("type")
    private String type;
    @JsonProperty("subType")
    private String subType;
    @JsonProperty("isEnergyStarCompliant")
    private Boolean isEnergyStarCompliant;

    public String getGlobalStatus() {
        return globalStatus;
    }

    public void setGlobalStatus(String globalStatus) {
        this.globalStatus = globalStatus;
    }

    public Long getOid() {
        return oid;
    }

    public void setOid(Long oid) {
        this.oid = oid;
    }

    public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }

    public CharacteristicCategories getCharacteristicCategories() {
        return characteristicCategories;
    }

    public void setCharacteristicCategories(CharacteristicCategories characteristicCategories) {
        this.characteristicCategories = characteristicCategories;
    }

    public String getCommercialReference() {
        return commercialReference;
    }

    public void setCommercialReference(String commercialReference) {
        this.commercialReference = commercialReference;
    }

    public CommercializedProduct getCommercializedProduct() {
        return commercializedProduct;
    }

    public void setCommercializedProduct(CommercializedProduct commercializedProduct) {
        this.commercializedProduct = commercializedProduct;
    }

    public DocumentOids getDocumentOids() {
        return documentOids;
    }

    public void setDocumentOids(DocumentOids documentOids) {
        this.documentOids = documentOids;
    }

    public String getEanCode() {
        return eanCode;
    }

    public void setEanCode(String eanCode) {
        this.eanCode = eanCode;
    }

    public Long getEpdsDocumentOid() {
        return epdsDocumentOid;
    }

    public void setEpdsDocumentOid(Long epdsDocumentOid) {
        this.epdsDocumentOid = epdsDocumentOid;
    }

    public Boolean getGreenPremium() {
        return greenPremium;
    }

    public void setGreenPremium(Boolean greenPremium) {
        this.greenPremium = greenPremium;
    }

    public HighligthedCharacteristics getHighligthedCharacteristics() {
        return highligthedCharacteristics;
    }

    public void setHighligthedCharacteristics(HighligthedCharacteristics highligthedCharacteristics) {
        this.highligthedCharacteristics = highligthedCharacteristics;
    }

    public String getLongDescription() {
        return longDescription;
    }

    public void setLongDescription(String longDescription) {
        this.longDescription = longDescription;
    }

    public Long getParentNodeOid() {
        return parentNodeOid;
    }

    public void setParentNodeOid(Long parentNodeOid) {
        this.parentNodeOid = parentNodeOid;
    }

    public String getParentRangeId() {
        return parentRangeId;
    }

    public void setParentRangeId(String parentRangeId) {
        this.parentRangeId = parentRangeId;
    }

    public Long getParentRangeOid() {
        return parentRangeOid;
    }

    public void setParentRangeOid(Long parentRangeOid) {
        this.parentRangeOid = parentRangeOid;
    }

    public Long getPictureDocumentOid() {
        return pictureDocumentOid;
    }

    public void setPictureDocumentOid(Long pictureDocumentOid) {
        this.pictureDocumentOid = pictureDocumentOid;
    }

    public Parents getParents() {
        return parents;
    }

    public void setParents(Parents parents) {
        this.parents = parents;
    }

    public Ranges getRanges() {
        return ranges;
    }

    public void setRanges(Ranges ranges) {
        this.ranges = ranges;
    }

    public String getShortDescription() {
        return shortDescription;
    }

    public void setShortDescription(String shortDescription) {
        this.shortDescription = shortDescription;
    }

    public DocumentReferences getDocumentReferences() {
        return documentReferences;
    }

    public void setDocumentReferences(DocumentReferences documentReferences) {
        this.documentReferences = documentReferences;
    }

    public String getPictureDocumentReference() {
        return pictureDocumentReference;
    }

    public void setPictureDocumentReference(String pictureDocumentReference) {
        this.pictureDocumentReference = pictureDocumentReference;
    }

    public Pictures getPictures() {
        return pictures;
    }

    public void setPictures(Pictures pictures) {
        this.pictures = pictures;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getSubType() {
        return subType;
    }

    public void setSubType(String subType) {
        this.subType = subType;
    }

    public Boolean getIsEnergyStarCompliant() {
        return isEnergyStarCompliant;
    }

    public void setIsEnergyStarCompliant(Boolean isEnergyStarCompliant) {
        this.isEnergyStarCompliant = isEnergyStarCompliant;
    }
}
