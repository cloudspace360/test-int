
package com.schneider.rest.product.service.responses;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Parent {

	@JsonProperty("nodeOid")
	private Long nodeOid;
	@JsonProperty("rangeId")
	private String rangeId;
	@JsonProperty("rangeOid")
	private Long rangeOid;

	public Long getNodeOid() {
		return nodeOid;
	}

	public void setNodeOid(Long nodeOid) {
		this.nodeOid = nodeOid;
	}

	public String getRangeId() {
		return rangeId;
	}

	public void setRangeId(String rangeId) {
		this.rangeId = rangeId;
	}

	public Long getRangeOid() {
		return rangeOid;
	}

	public void setRangeOid(Long rangeOid) {
		this.rangeOid = rangeOid;
	}
}
