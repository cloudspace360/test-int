
package com.schneider.oreo.service.document;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for documentBeanV002 complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="documentBeanV002"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://document.service.oreo.schneider.com/}documentBeanV001"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="displayOrder" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/&gt;
 *         &lt;element name="fileContents" type="{http://document.service.oreo.schneider.com/}fileContentBean" minOccurs="0"/&gt;
 *         &lt;element name="flipFlopGenerated" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "documentBeanV002", propOrder = {
    "displayOrder",
    "fileContents",
    "flipFlopGenerated"
})
public class DocumentBeanV002
    extends DocumentBeanV001
{

    protected Integer displayOrder;
    protected FileContentBean fileContents;
    protected Boolean flipFlopGenerated;

    /**
     * Gets the value of the displayOrder property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getDisplayOrder() {
        return displayOrder;
    }

    /**
     * Sets the value of the displayOrder property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setDisplayOrder(Integer value) {
        this.displayOrder = value;
    }

    /**
     * Gets the value of the fileContents property.
     * 
     * @return
     *     possible object is
     *     {@link FileContentBean }
     *     
     */
    public FileContentBean getFileContents() {
        return fileContents;
    }

    /**
     * Sets the value of the fileContents property.
     * 
     * @param value
     *     allowed object is
     *     {@link FileContentBean }
     *     
     */
    public void setFileContents(FileContentBean value) {
        this.fileContents = value;
    }

    /**
     * Gets the value of the flipFlopGenerated property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isFlipFlopGenerated() {
        return flipFlopGenerated;
    }

    /**
     * Sets the value of the flipFlopGenerated property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setFlipFlopGenerated(Boolean value) {
        this.flipFlopGenerated = value;
    }

}
