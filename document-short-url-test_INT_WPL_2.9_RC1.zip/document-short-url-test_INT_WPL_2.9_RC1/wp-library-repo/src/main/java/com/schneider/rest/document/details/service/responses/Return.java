
package com.schneider.rest.document.details.service.responses;

import javax.xml.datatype.XMLGregorianCalendar;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.schneider.rest.document.service.responses.DocTypeGroup;
import com.schneider.rest.document.service.responses.DocumentTypeBean;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Return {

	@JsonProperty("author")
	private String author;
	@JsonProperty("attributeLists")
	private AttributeLists attributeLists;
	@JsonProperty("attributes")
	private Attributes attributes;
	@JsonProperty("audience")
	private AudienceBean audience;
	@JsonProperty("businessAudience")
	private BusinessAudience businessAudience;
	@JsonProperty("channels")
	private Channels channels;
	@JsonProperty("creationDate")
	private String creationDate;
	@JsonProperty("docId")
	private String docId;
	@JsonProperty("docOwner")
	private String docOwner;
	@JsonProperty("documentDate")
	private XMLGregorianCalendar documentDate;
	@JsonProperty("documentType")
	private DocumentTypeBean documentType;
	@JsonProperty("files")
	private Files files;
	@JsonProperty("keywords")
	private String keywords;
	@JsonProperty("lastModificationDate")
	private XMLGregorianCalendar lastModificationDate;
	@JsonProperty("locales")
	private Locales locales;
	@JsonProperty("numberOfPage")
	private Integer numberOfPage;
	@JsonProperty("productReferences")
	private ProductReferences productReferences;
	@JsonProperty("ranges")
	private Ranges ranges;
	@JsonProperty("reference")
	private String reference;
	@JsonProperty("title")
	private String title;
	@JsonProperty("version")
	private String version;
	@JsonProperty("flipFlopGenerated")
	private Boolean flipFlopGenerated;
	@JsonProperty("bannerUrl")
	private String bannerUrl;
	@JsonProperty("revision")
	private String revision;
	@JsonProperty("docTypeGroups")
	private DocTypeGroups docTypeGroups;
	@JsonProperty("description")
	protected String description;
	@JsonProperty("versions")
	private Versions versions;
	@JsonProperty("translatedDocs")
	private TranslatedDocs translatedDocs;

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public AttributeLists getAttributeLists() {
		return attributeLists;
	}

	public void setAttributeLists(AttributeLists attributeLists) {
		this.attributeLists = attributeLists;
	}

	public Attributes getAttributes() {
		return attributes;
	}

	public void setAttributes(Attributes attributes) {
		this.attributes = attributes;
	}

	public AudienceBean getAudience() {
		return audience;
	}

	public void setAudience(AudienceBean audience) {
		this.audience = audience;
	}

	public BusinessAudience getBusinessAudience() {
		return businessAudience;
	}

	public void setBusinessAudience(BusinessAudience businessAudience) {
		this.businessAudience = businessAudience;
	}

	public Channels getChannels() {
		return channels;
	}

	public void setChannels(Channels channels) {
		this.channels = channels;
	}

	public String getCreationDate() {
		return creationDate;
	}

	public String getDocId() {
		return docId;
	}

	public void setDocId(String docId) {
		this.docId = docId;
	}

	public String getDocOwner() {
		return docOwner;
	}

	public void setDocOwner(String docOwner) {
		this.docOwner = docOwner;
	}

	public XMLGregorianCalendar getDocumentDate() {
		return documentDate;
	}

	public void setDocumentDate(XMLGregorianCalendar documentDate) {
		this.documentDate = documentDate;
	}

	public DocumentTypeBean getDocumentType() {
		return documentType;
	}

	public void setDocumentType(DocumentTypeBean documentType) {
		this.documentType = documentType;
	}

	public Files getFiles() {
		return files;
	}

	public void setFiles(Files files) {
		this.files = files;
	}

	public String getKeywords() {
		return keywords;
	}

	public void setKeywords(String keywords) {
		this.keywords = keywords;
	}

	public XMLGregorianCalendar getLastModificationDate() {
		return lastModificationDate;
	}

	public void setLastModificationDate(XMLGregorianCalendar lastModificationDate) {
		this.lastModificationDate = lastModificationDate;
	}

	public Locales getLocales() {
		return locales;
	}

	public void setLocales(Locales locales) {
		this.locales = locales;
	}

	public Integer getNumberOfPage() {
		return numberOfPage;
	}

	public void setNumberOfPage(Integer numberOfPage) {
		this.numberOfPage = numberOfPage;
	}

	public ProductReferences getProductReferences() {
		return productReferences;
	}

	public void setProductReferences(ProductReferences productReferences) {
		this.productReferences = productReferences;
	}

	public Ranges getRanges() {
		return ranges;
	}

	public void setRanges(Ranges ranges) {
		this.ranges = ranges;
	}

	public String getReference() {
		return reference;
	}

	public void setReference(String reference) {
		this.reference = reference;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getVersion() {
		return version;
	}

	public void setVersion(String version) {
		this.version = version;
	}

	public Boolean getFlipFlopGenerated() {
		return flipFlopGenerated;
	}

	public void setFlipFlopGenerated(Boolean flipFlopGenerated) {
		this.flipFlopGenerated = flipFlopGenerated;
	}

	public void setCreationDate(String creationDate) {
		this.creationDate = creationDate;
	}

	public String getBannerUrl() {
		return bannerUrl;
	}

	public void setBannerUrl(String bannerUrl) {
		this.bannerUrl = bannerUrl;
	}

	public String getRevision() {
		return revision;
	}

	public void setRevision(String revision) {
		this.revision = revision;
	}

	public DocTypeGroups getDocTypeGroups() {
		return docTypeGroups;
	}

	public void setDocTypeGroups(DocTypeGroups docTypeGroups) {
		this.docTypeGroups = docTypeGroups;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Versions getVersions() {
		return versions;
	}

	public void setVersions(Versions versions) {
		this.versions = versions;
	}

	public TranslatedDocs getTranslatedDocs() {
		return translatedDocs;
	}

	public void setTranslatedDocs(TranslatedDocs translatedDocs) {
		this.translatedDocs = translatedDocs;
	}
}
