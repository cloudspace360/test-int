
package com.schneider.oreo.service.document;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for documentPageBean complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="documentPageBean"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="documentCounts" minOccurs="0"&gt;
 *           &lt;complexType&gt;
 *             &lt;complexContent&gt;
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                 &lt;sequence&gt;
 *                   &lt;element name="documentCount" type="{http://document.service.oreo.schneider.com/}documentPageCountResult" maxOccurs="unbounded" minOccurs="0"/&gt;
 *                 &lt;/sequence&gt;
 *               &lt;/restriction&gt;
 *             &lt;/complexContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="documents" minOccurs="0"&gt;
 *           &lt;complexType&gt;
 *             &lt;complexContent&gt;
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                 &lt;sequence&gt;
 *                   &lt;element name="document" type="{http://document.service.oreo.schneider.com/}documentPageDocumentBean" maxOccurs="unbounded" minOccurs="0"/&gt;
 *                 &lt;/sequence&gt;
 *               &lt;/restriction&gt;
 *             &lt;/complexContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="misspelledSearchString" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "documentPageBean", propOrder = {
    "documentCounts",
    "documents",
    "misspelledSearchString"
})
public class DocumentPageBean {

    protected DocumentPageBean.DocumentCounts documentCounts;
    protected DocumentPageBean.Documents documents;
    protected String misspelledSearchString;

    /**
     * Gets the value of the documentCounts property.
     * 
     * @return
     *     possible object is
     *     {@link DocumentPageBean.DocumentCounts }
     *     
     */
    public DocumentPageBean.DocumentCounts getDocumentCounts() {
        return documentCounts;
    }

    /**
     * Sets the value of the documentCounts property.
     * 
     * @param value
     *     allowed object is
     *     {@link DocumentPageBean.DocumentCounts }
     *     
     */
    public void setDocumentCounts(DocumentPageBean.DocumentCounts value) {
        this.documentCounts = value;
    }

    /**
     * Gets the value of the documents property.
     * 
     * @return
     *     possible object is
     *     {@link DocumentPageBean.Documents }
     *     
     */
    public DocumentPageBean.Documents getDocuments() {
        return documents;
    }

    /**
     * Sets the value of the documents property.
     * 
     * @param value
     *     allowed object is
     *     {@link DocumentPageBean.Documents }
     *     
     */
    public void setDocuments(DocumentPageBean.Documents value) {
        this.documents = value;
    }

    /**
     * Gets the value of the misspelledSearchString property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMisspelledSearchString() {
        return misspelledSearchString;
    }

    /**
     * Sets the value of the misspelledSearchString property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMisspelledSearchString(String value) {
        this.misspelledSearchString = value;
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;complexContent&gt;
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *       &lt;sequence&gt;
     *         &lt;element name="documentCount" type="{http://document.service.oreo.schneider.com/}documentPageCountResult" maxOccurs="unbounded" minOccurs="0"/&gt;
     *       &lt;/sequence&gt;
     *     &lt;/restriction&gt;
     *   &lt;/complexContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "documentCount"
    })
    public static class DocumentCounts {

        protected List<DocumentPageCountResult> documentCount;

        /**
         * Gets the value of the documentCount property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the documentCount property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getDocumentCount().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link DocumentPageCountResult }
         * 
         * 
         */
        public List<DocumentPageCountResult> getDocumentCount() {
            if (documentCount == null) {
                documentCount = new ArrayList<DocumentPageCountResult>();
            }
            return this.documentCount;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;complexContent&gt;
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *       &lt;sequence&gt;
     *         &lt;element name="document" type="{http://document.service.oreo.schneider.com/}documentPageDocumentBean" maxOccurs="unbounded" minOccurs="0"/&gt;
     *       &lt;/sequence&gt;
     *     &lt;/restriction&gt;
     *   &lt;/complexContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "document"
    })
    public static class Documents {

        protected List<DocumentPageDocumentBean> document;

        /**
         * Gets the value of the document property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the document property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getDocument().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link DocumentPageDocumentBean }
         * 
         * 
         */
        public List<DocumentPageDocumentBean> getDocument() {
            if (document == null) {
                document = new ArrayList<DocumentPageDocumentBean>();
            }
            return this.document;
        }

    }

}
