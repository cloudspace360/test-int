
package com.schneider.rest.document.service.responses;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Program {

    @JsonProperty("name")
    private Name__3 name;

    public Name__3 getName() {
        return name;
    }

    public void setName(Name__3 name) {
        this.name = name;
    }
}
