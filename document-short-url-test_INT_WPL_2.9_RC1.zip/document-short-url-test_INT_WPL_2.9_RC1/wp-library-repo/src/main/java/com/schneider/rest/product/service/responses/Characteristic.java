
package com.schneider.rest.product.service.responses;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Characteristic {

	@JsonProperty("charId")
	private String charId;
	@JsonProperty("charKey")
	private String charKey;
	@JsonProperty("name")
	private String name;
	@JsonProperty("oid")
	private Long oid;
	@JsonProperty("displayName")
	private String displayName;
	@JsonProperty("description")
	private String description;
	@JsonProperty("values")
	private Values values;

	public String getCharId() {
		return charId;
	}

	public void setCharId(String charId) {
		this.charId = charId;
	}

	public String getCharKey() {
		return charKey;
	}

	public void setCharKey(String charKey) {
		this.charKey = charKey;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Long getOid() {
		return oid;
	}

	public void setOid(Long oid) {
		this.oid = oid;
	}

	public String getDisplayName() {
		return displayName;
	}

	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Characteristic withDescription(String description) {
		this.description = description;
		return this;
	}

	public Values getValues() {
		return values;
	}

	public void setValues(Values values) {
		this.values = values;
	}
}
