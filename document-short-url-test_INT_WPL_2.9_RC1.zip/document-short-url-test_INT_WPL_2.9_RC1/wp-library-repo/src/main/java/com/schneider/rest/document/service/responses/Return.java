
package com.schneider.rest.document.service.responses;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Return {

    @JsonProperty("documentCounts")
    private DocumentCounts documentCounts;
    @JsonProperty("documents")
    private Documents documents;

    public DocumentCounts getDocumentCounts() {
        return documentCounts;
    }

    public void setDocumentCounts(DocumentCounts documentCounts) {
        this.documentCounts = documentCounts;
    }

    public Documents getDocuments() {
        return documents;
    }

    public void setDocuments(Documents documents) {
        this.documents = documents;
    }
}
