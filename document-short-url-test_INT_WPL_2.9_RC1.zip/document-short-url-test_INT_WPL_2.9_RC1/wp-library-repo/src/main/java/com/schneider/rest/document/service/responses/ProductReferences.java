
package com.schneider.rest.document.service.responses;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class ProductReferences {

    @JsonProperty("productReference")
    private List<ProductReference> productReference = new ArrayList<>();

    public List<ProductReference> getProductReference() {
        return productReference;
    }

    public void setProductReference(List<ProductReference> productReference) {
        this.productReference = productReference;
    }

    public ProductReferences withProductReference(List<ProductReference> productReference) {
        this.productReference = productReference;
        return this;
    }
}
