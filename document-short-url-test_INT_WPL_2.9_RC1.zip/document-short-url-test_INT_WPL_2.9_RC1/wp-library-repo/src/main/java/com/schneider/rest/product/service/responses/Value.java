
package com.schneider.rest.product.service.responses;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Value {

    @JsonProperty("lockCase")
    private Boolean lockCase;
    @JsonProperty("oid")
    private Long oid;
    @JsonProperty("value")
    private String value;
    @JsonProperty("valueId")
    private String valueId;
    @JsonProperty("visible")
    private Boolean visible;
    @JsonProperty("externetUrl")
    private String externetUrl;
    @JsonProperty("labelUrl")
    private String labelUrl;
    @JsonProperty("countryIso")
    private String countryIso;
    @JsonProperty("countryName")
    private String countryName;
    @JsonProperty("countryOid")
    private Long countryOid;

    public Boolean getLockCase() {
        return lockCase;
    }
    public void setLockCase(Boolean lockCase) {
        this.lockCase = lockCase;
    }

    public Long getOid() {
        return oid;
    }

    public void setOid(Long oid) {
        this.oid = oid;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public String getValueId() {
        return valueId;
    }

    public void setValueId(String valueId) {
        this.valueId = valueId;
    }

    public Boolean getVisible() {
        return visible;
    }

    public void setVisible(Boolean visible) {
        this.visible = visible;
    }

    public String getExternetUrl() {
        return externetUrl;
    }

    public void setExternetUrl(String externetUrl) {
        this.externetUrl = externetUrl;
    }

    public String getLabelUrl() {
        return labelUrl;
    }

    public void setLabelUrl(String labelUrl) {
        this.labelUrl = labelUrl;
    }

    public String getCountryIso() {
        return countryIso;
    }

    public void setCountryIso(String countryIso) {
        this.countryIso = countryIso;
    }

    public String getCountryName() {
        return countryName;
    }

    public void setCountryName(String countryName) {
        this.countryName = countryName;
    }

    public Long getCountryOid() {
        return countryOid;
    }

    public void setCountryOid(Long countryOid) {
        this.countryOid = countryOid;
    }
}
