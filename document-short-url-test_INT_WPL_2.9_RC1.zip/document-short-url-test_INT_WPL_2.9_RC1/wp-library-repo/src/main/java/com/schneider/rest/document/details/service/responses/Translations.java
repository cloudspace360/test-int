
package com.schneider.rest.document.details.service.responses;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Translations {

    @JsonProperty("translation")
    private List<Translation__1> translation = new ArrayList<>();

    public List<Translation__1> getTranslation() {
        return translation;
    }

    public void setTranslation(List<Translation__1> translation) {
        this.translation = translation;
    }
}
