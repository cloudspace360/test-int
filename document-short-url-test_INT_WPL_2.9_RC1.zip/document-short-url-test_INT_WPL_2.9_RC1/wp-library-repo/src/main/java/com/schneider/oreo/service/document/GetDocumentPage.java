
package com.schneider.oreo.service.document;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for getDocumentPage complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="getDocumentPage"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="applicationToken" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="scope" type="{http://document.service.oreo.schneider.com/}scopeBean"/&gt;
 *         &lt;element name="locale" type="{http://document.service.oreo.schneider.com/}localeBean" maxOccurs="unbounded"/&gt;
 *         &lt;element name="query" type="{http://document.service.oreo.schneider.com/}queryBean" minOccurs="0"/&gt;
 *         &lt;element name="search" type="{http://document.service.oreo.schneider.com/}searchBeans" minOccurs="0"/&gt;
 *         &lt;element name="countBy" type="{http://document.service.oreo.schneider.com/}docCountByBean" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="display" type="{http://document.service.oreo.schneider.com/}docDisplayBeans" minOccurs="0"/&gt;
 *         &lt;element name="order" type="{http://document.service.oreo.schneider.com/}docOrderBeans" minOccurs="0"/&gt;
 *         &lt;element name="pagination" type="{http://document.service.oreo.schneider.com/}paginationBean" minOccurs="0"/&gt;
 *         &lt;element name="maxCountResult" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *         &lt;element name="version" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "getDocumentPage", propOrder = {
    "applicationToken",
    "scope",
    "locale",
    "query",
    "search",
    "countBy",
    "display",
    "order",
    "pagination",
    "maxCountResult",
    "version"
})
public class GetDocumentPage {

    protected String applicationToken;
    @XmlElement(required = true)
    protected ScopeBean scope;
    @XmlElement(required = true)
    protected List<LocaleBean> locale;
    protected QueryBean query;
    protected SearchBeans search;
    protected List<DocCountByBean> countBy;
    protected DocDisplayBeans display;
    protected DocOrderBeans order;
    protected PaginationBean pagination;
    protected int maxCountResult;
    protected Long version;

    /**
     * Gets the value of the applicationToken property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getApplicationToken() {
        return applicationToken;
    }

    /**
     * Sets the value of the applicationToken property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setApplicationToken(String value) {
        this.applicationToken = value;
    }

    /**
     * Gets the value of the scope property.
     * 
     * @return
     *     possible object is
     *     {@link ScopeBean }
     *     
     */
    public ScopeBean getScope() {
        return scope;
    }

    /**
     * Sets the value of the scope property.
     * 
     * @param value
     *     allowed object is
     *     {@link ScopeBean }
     *     
     */
    public void setScope(ScopeBean value) {
        this.scope = value;
    }

    /**
     * Gets the value of the locale property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the locale property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getLocale().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link LocaleBean }
     * 
     * 
     */
    public List<LocaleBean> getLocale() {
        if (locale == null) {
            locale = new ArrayList<LocaleBean>();
        }
        return this.locale;
    }

    /**
     * Gets the value of the query property.
     * 
     * @return
     *     possible object is
     *     {@link QueryBean }
     *     
     */
    public QueryBean getQuery() {
        return query;
    }

    /**
     * Sets the value of the query property.
     * 
     * @param value
     *     allowed object is
     *     {@link QueryBean }
     *     
     */
    public void setQuery(QueryBean value) {
        this.query = value;
    }

    /**
     * Gets the value of the search property.
     * 
     * @return
     *     possible object is
     *     {@link SearchBeans }
     *     
     */
    public SearchBeans getSearch() {
        return search;
    }

    /**
     * Sets the value of the search property.
     * 
     * @param value
     *     allowed object is
     *     {@link SearchBeans }
     *     
     */
    public void setSearch(SearchBeans value) {
        this.search = value;
    }

    /**
     * Gets the value of the countBy property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the countBy property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getCountBy().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DocCountByBean }
     * 
     * 
     */
    public List<DocCountByBean> getCountBy() {
        if (countBy == null) {
            countBy = new ArrayList<DocCountByBean>();
        }
        return this.countBy;
    }

    /**
     * Gets the value of the display property.
     * 
     * @return
     *     possible object is
     *     {@link DocDisplayBeans }
     *     
     */
    public DocDisplayBeans getDisplay() {
        return display;
    }

    /**
     * Sets the value of the display property.
     * 
     * @param value
     *     allowed object is
     *     {@link DocDisplayBeans }
     *     
     */
    public void setDisplay(DocDisplayBeans value) {
        this.display = value;
    }

    /**
     * Gets the value of the order property.
     * 
     * @return
     *     possible object is
     *     {@link DocOrderBeans }
     *     
     */
    public DocOrderBeans getOrder() {
        return order;
    }

    /**
     * Sets the value of the order property.
     * 
     * @param value
     *     allowed object is
     *     {@link DocOrderBeans }
     *     
     */
    public void setOrder(DocOrderBeans value) {
        this.order = value;
    }

    /**
     * Gets the value of the pagination property.
     * 
     * @return
     *     possible object is
     *     {@link PaginationBean }
     *     
     */
    public PaginationBean getPagination() {
        return pagination;
    }

    /**
     * Sets the value of the pagination property.
     * 
     * @param value
     *     allowed object is
     *     {@link PaginationBean }
     *     
     */
    public void setPagination(PaginationBean value) {
        this.pagination = value;
    }

    /**
     * Gets the value of the maxCountResult property.
     * 
     */
    public int getMaxCountResult() {
        return maxCountResult;
    }

    /**
     * Sets the value of the maxCountResult property.
     * 
     */
    public void setMaxCountResult(int value) {
        this.maxCountResult = value;
    }

    /**
     * Gets the value of the version property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getVersion() {
        return version;
    }

    /**
     * Sets the value of the version property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setVersion(Long value) {
        this.version = value;
    }

}
