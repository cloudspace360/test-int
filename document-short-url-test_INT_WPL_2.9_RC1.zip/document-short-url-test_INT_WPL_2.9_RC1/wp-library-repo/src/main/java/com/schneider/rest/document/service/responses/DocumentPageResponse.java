
package com.schneider.rest.document.service.responses;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class DocumentPageResponse {

    @JsonProperty("getDocumentPageResponse")
    private GetDocumentPageResponse getDocumentPageResponse;

    public GetDocumentPageResponse getGetDocumentPageResponse() {
        return getDocumentPageResponse;
    }

    public void setGetDocumentPageResponse(GetDocumentPageResponse getDocumentPageResponse) {
        this.getDocumentPageResponse = getDocumentPageResponse;
    }
}
