
package com.schneider.rest.document.details.service.responses;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class ProductReference {

    @JsonProperty("commRef")
    private String commRef;
    @JsonProperty("main")
    private Boolean main;
    @JsonProperty("alternative")
    private Boolean alternative;

    public String getCommRef() {
        return commRef;
    }

    public void setCommRef(String commRef) {
        this.commRef = commRef;
    }

    public Boolean getMain() {
        return main;
    }

    public void setMain(Boolean main) {
        this.main = main;
    }

    public Boolean getAlternative() {
        return alternative;
    }

    public void setAlternative(Boolean alternative) {
        this.alternative = alternative;
    }
}
